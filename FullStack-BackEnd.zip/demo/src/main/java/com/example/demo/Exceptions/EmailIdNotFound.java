package com.example.demo.Exceptions;

public class EmailIdNotFound extends RuntimeException {

	public EmailIdNotFound(String message) {
		super(message);
		
	}
	

}
