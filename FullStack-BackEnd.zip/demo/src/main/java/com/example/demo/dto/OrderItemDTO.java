package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//OrderItemDTO.java
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemDTO {
 private String menuName;
 private int quantity;
 private double price;
}
