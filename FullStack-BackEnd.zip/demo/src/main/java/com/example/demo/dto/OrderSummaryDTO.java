package com.example.demo.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderSummaryDTO {
 private int orderId;
 private String customerName;
 private String restaurantName;
 private String shippingAddress;
 private String paymentMethod;
 private Double totalAmount;
 private LocalDateTime orderTime;
 private String status;
 private List<OrderItemDTO> items;
}
