package com.example.demo.Services;

import java.util.Collections;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Admin;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Repository.AdminRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Repository.UserRepo;
@Service
public class CustemUserDetailService implements UserDetailsService{
		@Autowired 
		private UserRepo userRepo;
		@Autowired
		private RestaurantRepo resrepo;
		@Autowired
		private AdminRepo adminrepo;
	
	  @Override
	  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
		  
		  
		 Optional<User> useropt=userRepo.findByEmail(username);
		 if(useropt.isPresent()) {
			 User user=useropt.get();
			 return new org.springframework.security.core.userdetails.User(
					 user.getEmail(),
					 user.getPassword(),
					 Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+user.getRole())));
		 }
		 Optional<Restaurant> restaurantopt=resrepo.findByEmail(username);
		 if(restaurantopt.isPresent()) {
			 Restaurant res=restaurantopt.get();
			 return new org.springframework.security.core.userdetails.User(res.getEmail(),
					 res.getPassword(),
					 Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+res.getRole())));
			 }
		 Optional<Admin> adminopt=adminrepo.findByEmail(username);
		 if(adminopt.isPresent()) {
			 Admin admin=adminopt.get();
			 return new org.springframework.security.core.userdetails.User(admin.getEmail(),
					 admin.getPassword(),
					 Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+admin.getRole())));
		 }
		 throw new UsernameNotFoundException("Email Id not found");
		 
}
}