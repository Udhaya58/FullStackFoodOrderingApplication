package com.example.demo.Exceptions;

public class MenuNotFound extends RuntimeException {

	public MenuNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
