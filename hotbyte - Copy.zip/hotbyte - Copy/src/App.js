import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import RestaurantDashboard from './pages/RestaurantDashboard';
import AdminDashboard from './pages/AdminDashboard';
import UserDashBoard from './pages/UserDashBoard';
import Register from './pages/Register';
import Menu from './pages/Menu';
import AddMenu from './pages/AddMenu';
import EditMenu from './pages/EditMenu';
import UpdateMenu from './pages/UpdateMenu';
import InStockMenu from './pages/InStockMenu';
import OutOfStockMenu from './pages/OutOfStockMenu';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderSummaryPage from './pages/OrderSummaryPage';
import OrdersPage from './pages/OrdersPage';
import OrderManagement from './pages/OrderManagement';
import PendingOrders from './pages/PendingOrders';
import ProcessingOrders from './pages/ProcessingOrders';
import OutForDeliveryOrders from './pages/OutForDeliveryOrders';
import OrderHistory from './pages/OrderHistory';
import Usermanagement from './pages/Usermanagement';
import ManageCustomer from './pages/ManageCustomer';
import AddCustomer from './pages/AddCustomer';
import DeleteCustomer from './pages/DeleteCustomer';
import RestaurantManagement from './pages/RestaurantManagement';
import AddRestaurant from './pages/AddRestaurant';
import DeleteRestaurant from './pages/DeleteRestaurant';
import AdminMenuManagement from './pages/AdminMenuManagement';
import AdminRestaurantMenu from './pages/AdminRestaurantMenu';
import AdminUpdateMenu from './pages/AdminUpdateMenu';

function App() {
  return (
   <BrowserRouter>
   <Routes>
    <Route path="/" element={<Login/>}/>
    <Route path="/user" element={<UserDashBoard/>}/>
    <Route path="/restaurant" element={<RestaurantDashboard/>}/>
    <Route path="/admin" element={<AdminDashboard/>}/>
    <Route path="/register" element={<Register/>}/>
    <Route path="/menumanagement" element={<Menu/>}/>
    <Route path='/addmenu' element={<AddMenu/>}/>
    <Route path='/editmenu' element={<EditMenu/>}/>
    <Route path='/editmenu/:id' element={<UpdateMenu/>}/>
    <Route path='/instock' element={<InStockMenu/>}/>
    <Route path='/outofstock' element={<OutOfStockMenu/>}/>
    <Route path='/product/:id' element={<ProductPage/>}/>
    <Route path='/cart' element={<CartPage/>}/>
    <Route path='/checkout' element={<CheckoutPage/>}/>
    <Route path="/order-summary/:id" element={<OrderSummaryPage/>}/> 
    <Route path='/orderpage' element={<OrdersPage/>}/>
    <Route path='/ordermanagement' element={<OrderManagement/>}/>
    <Route path='/pendingorders' element={<PendingOrders/>}/>
    <Route path='/processingorders' element={<ProcessingOrders/>}/>
    <Route path='/outfordeliveryorders' element={<OutForDeliveryOrders/>}/>
    <Route path='/orderhistory' element={<OrderHistory/>}/>
    <Route path='/usermanagement' element={<Usermanagement/>}/>
    <Route path='/managecustomers' element={<ManageCustomer/>}/>
    <Route path='/addcustomer'element={<AddCustomer/>}/>
    <Route path='/deletecustomer' element={<DeleteCustomer/>}/>
    <Route path='/managerestaurants' element={<RestaurantManagement/>}/>
    <Route path='/addrestaurant' element={<AddRestaurant/>}/>
    <Route path='/deleterestaurant' element={<DeleteRestaurant/>}/>
    <Route path='adminmenu' element={<AdminMenuManagement/>}/>
    <Route path="/adminrestaurantmenu/:restaurantId" element={<AdminRestaurantMenu />} />
    <Route path="/adminupdatemenu/:menuId" element={<AdminUpdateMenu />} />
   </Routes>
   </BrowserRouter>
  );
}

export default App;
