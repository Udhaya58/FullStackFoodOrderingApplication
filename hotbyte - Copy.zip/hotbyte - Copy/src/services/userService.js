import API from "../api/axiosConfig"

export const getAllMenu=()=>{
    return API.get(`/api/user/menus`);
}


export const getMenuByName = (menuname) => {
  return API.get(`/api/user/menus/search`, {
    params: {
      keyword: menuname
    }
  });
};


export const getFilterMenu = (category, dietary, minPrice, maxPrice) => {
  return API.get(`/api/user/menus/filter`, {
    params: {
      category: category,
      dietary: dietary,
      minPrice: minPrice,
      maxPrice: maxPrice
    }
  });
};


export const getMenuById=(id)=>{
    return API.get(`/api/user/menu/getid/${id}`);
}

export const addToCart = (menuId, quantity) => {
  return API.post("/api/user/cart/add",null, {
    params: {
      menuId: menuId,
      quantity: quantity
    }
  });
};

export const getCart = () => {
  return API.get("/api/user/cart");
};

export const updateQuantity = (itemId, quantity) => {
  return API.put(`/api/user/cart/item/${itemId}/quantity?quantity=${quantity}`);
};

export const removeItem = (itemId) => {
  return API.delete(`/api/user/cart/item/${itemId}`);
};

export const checkout = (orderData) => {
  return API.post("/api/user/checkout", orderData);
};


export const getOrderSummary = (orderId) => {
  return API.get(`/api/user/order/summary/${orderId}`);
};

export const getUserOrders = () => {
  return API.get("/api/user/orders");
};