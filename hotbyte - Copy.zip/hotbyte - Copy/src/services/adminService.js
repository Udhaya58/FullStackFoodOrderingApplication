import API from '../api/axiosConfig'

export const RegisterUser=(data)=>{
    return API.post(`/api/admin/add-user`,data)

}

export const getAllUsers = () => {
  return API.get(`/api/admin/users`);
};

export const deleteUser = (id) => {
  return API.delete(`/api/admin/delete-user/${id}`);
};

export const RegisterRestaurant = (data) => {
  return API.post(`/api/admin/add-restaurant`, data);
};

export const getAllRestaurants = () => {
  return API.get("/api/admin/restaurants");
};

export const deleteRestaurant = (id) => {
  return API.delete(`/api/admin/delete-restaurant/${id}`);
};

export const getRestaurantMenusById = (restaurantId) => {
  return API.get(`/api/admin/restaurant/getmenu/${restaurantId}`);
};

export const deleteMenuByAdmin = (menuId) => {
  return API.delete(`/api/admin/delete-menu/${menuId}`);
};
export const getMenuById= (menuId) => {
  return API.get(`/api/admin/menu/${menuId}`);
};

export const updateMenuByAdmin = (menuId, data) => {
  return API.put(`/api/admin/update-menu/${menuId}`, data);
};