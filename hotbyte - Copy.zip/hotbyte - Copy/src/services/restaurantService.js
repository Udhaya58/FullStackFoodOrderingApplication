import API from "../api/axiosConfig"

export const addMenu=(data)=>{
   return API.post("/api/restaurant/menu",data);
};

export const getAllMenu = () => {
  return API.get("/api/restaurant/menus");
};

export const getMenuById = (id) => {
  return API.get(`/api/restaurant/menu/${id}`);
};

export const updateMenu = (id, data) => {
  return API.put(`/api/restaurant/menu/${id}`, data);
};

export const deleteMenu = (id) => {
  return API.delete(`/api/restaurant/menu/${id}`);
};

export const instock=()=>{
  return API.get(`/api/restaurant/menu/instock`);
}
export const makeOutOfStock=(id)=>{
  return API.put(`/api/restaurant/menu/${id}/out-of-stock`);
}


export const outstock=()=>{
  return API.get(`/api/restaurant/menu/outstock`);
}

export const makeInStock=(id)=>{
  return API.put(`/api/restaurant/menu/${id}/in-stock`);
}


export const pendingOrders = () => {
  return API.get("/api/restaurant/orders/pending");
};

export const orderProcessing = (orderId) => {
  return API.put(`/api/restaurant/orders/processing/${orderId}`);
};

export const cancelOrder = (orderId) => {
  return API.put(`/api/restaurant/orders/${orderId}/cancelled`);
};

export const processingOrders = () => {
  return API.get("/api/restaurant/orders/processing");
};

export const outForDelivery = (orderId) => {
  return API.put(`/api/restaurant/orders/${orderId}/outfordelivery`);
};

export const outForDeliveryOrders = () => {
  return API.get("/api/restaurant/orders/outfordelivery");
};

export const markDelivered = (orderId) => {
  return API.put(`/api/restaurant/orders/${orderId}/delivered`);
};
export const restaurantOrderHistory = () => {
  return API.get("/api/restaurant/orders/history");
};