import API from "../api/axiosConfig"

export const loginUser=(data)=>{
    return API.post("/auth/login",data);
};

export const RegisterUser=(RegisterData)=>{
    return API.post("/auth/register",RegisterData);
};