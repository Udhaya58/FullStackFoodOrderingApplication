import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  outstock,
  makeInStock
} from "../services/restaurantService";
import "../CSS/OutOfStockMenu.css";

export default function OutOfStockMenu() {
  const [menuList, setMenuList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOutOfStockMenu();
  }, []);

  const fetchOutOfStockMenu = async () => {
    try {
      const res = await outstock();
      setMenuList(res.data || []);
    } catch (error) {
      console.error("Failed to fetch out-of-stock menu", error);
      alert("Failed to fetch out-of-stock items");
    }
  };

  const handleMarkInStock = async (id) => {
    try {
      await makeInStock(id);
      alert("Item marked as In Stock");
      fetchOutOfStockMenu();
    } catch (error) {
      console.error("Failed to update stock", error);
      alert("Failed to mark item as in stock");
    }
  };

  return (
    <div className="outstock-container">
      <div className="outstock-header">
        <h1>Out of Stock Items</h1>

        <button
          className="home-btn"
          onClick={() => navigate("/menumanagement")}
        >
           Back
        </button>
      </div>

      {menuList.length === 0 ? (
        <p className="empty-text">No out-of-stock items found.</p>
      ) : (
        <div className="menu-grid">
          {menuList.map((item) => (
            <div className="menu-card" key={item.id}>
              <img
                src={item.url}
                alt={item.name}
                className="menu-image"
              />

              <div className="menu-details">
                <h3>{item.name}</h3>
                <p>{item.description}</p>
                <p><strong>Category:</strong> {item.category}</p>
                <p><strong>Dietary:</strong> {item.dietaryType}</p>
                <p><strong>Taste:</strong> {item.tasteinfo}</p>
                <p><strong>Price:</strong> ₹{item.price}</p>
                <p className="status out">Out of Stock</p>

                <button
                  className="instock-btn"
                  onClick={() => handleMarkInStock(item.id)}
                >
                  Mark In Stock
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}