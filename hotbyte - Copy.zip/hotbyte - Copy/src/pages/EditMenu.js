import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllMenu, deleteMenu } from "../services/restaurantService";
import "../CSS/EditMenu.css";

export default function EditMenu() {
  const [menuList, setMenuList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const res = await getAllMenu();
      setMenuList(res.data);
    } catch (error) {
      alert("Failed to fetch menu");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        await deleteMenu(id);
        alert("Deleted Successfully");
        fetchMenu();
      } catch (error) {
        alert("Delete failed");
      }
    }
  };

  return (
    <div className="edit-container">

      {/* 🔥 Top Header Section */}
      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/menumanagement")}
        >
          ← Back to Dashboard
        </button>

        <h2 className="page-title">Update Menu Items</h2>
      </div>

      <div className="menu-grid">
        {menuList.map((item) => (
          <div className="menu-card" key={item.id}>
            <img
              src={item.url}
              alt={item.name}
              className="menu-image"
            />

            <div className="menu-content">
              <h3>{item.name}</h3>
              <p className="description">{item.description}</p>

              <div className="menu-details">
                <p><strong>Category:</strong> {item.category}</p>
                <p><strong>Price:</strong> ₹{item.price}</p>
                <p><strong>Diet:</strong> {item.dietaryType}</p>
                <p><strong>Taste:</strong> {item.tasteinfo}</p>
                <p>
                  <strong>Status:</strong>{" "}
                  <span className={item.available ? "available" : "not-available"}>
                    {item.available ? "In Stock" : "Out of Stock"}
                  </span>
                </p>
              </div>

              <div className="button-group">
                <button
                  className="update-btn"
                  onClick={() => navigate(`/editmenu/${item.id}`)}
                >
                  Update
                </button>

                <button
                  className="delete-btn"
                  onClick={() => handleDelete(item.id)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}