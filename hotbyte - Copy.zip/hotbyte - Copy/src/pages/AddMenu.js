import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { addMenu } from '../services/restaurantService';
import "../CSS/AddMenu.css"

export default function AddMenu() {
  const navigate = useNavigate();

  const categories = [
    "STARTERS", "MAIN_COURSE", "DESSERTS",
    "BEVERAGES", "SNACKS", "SALADS", "SOUPS"
  ];

  const dietaryTypes = ["VEG", "NONVEG"];

  const tasteInfos = [
    "SWEET", "SPICY_LIGHT", "SPICY_FULL",
    "MILD", "SALTY", "SOUR"
  ];

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    keyInged: "",
    price: "",
    availableTime: "",
    url: "",
    category: "",
    dietaryType: "",
    tasteinfo: "",
    available: true,
    nutrionalInfo: ""
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [success, setSuccess] = useState("");

  const nameRegex = /^[A-Za-z\s]+$/;
  const priceRegex = /^[0-9]+$/;

  const validate = (field, value) => {
    let error = "";

    if (!value && field !== "available") {
      error = `${field} is required`;
    } else {
      if (field === "name" && value && !nameRegex.test(value)) {
        error = "Only letters and spaces allowed";
      }
      if (field === "price" && value && !priceRegex.test(value)) {
        error = "Price must be numeric";
      }
    }
    return error;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const fieldValue = type === "checkbox" ? checked : value;

    setFormData({ ...formData, [name]: fieldValue });

    const error = validate(name, fieldValue);
    setErrors({ ...errors, [name]: error });

    setSuccess("");
  };

  const handleBlur = (e) => {
    setTouched({ ...touched, [e.target.name]: true });
  };

  const isFormValid =
    nameRegex.test(formData.name) &&
    priceRegex.test(formData.price) &&
    formData.description &&
    formData.keyInged &&
    formData.availableTime &&
    formData.category &&
    formData.dietaryType &&
    formData.tasteinfo;

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isFormValid) {
      const finalData = {
        ...formData,
        price: Number(formData.price)
      };

      addMenu(finalData)
        .then(() => {
          setSuccess("Menu Item Added Successfully!");

          setFormData({
            name: "",
            description: "",
            keyInged: "",
            price: "",
            availableTime: "",
            url: "",
            category: "",
            dietaryType: "",
            tasteinfo: "",
            available: true,
            nutrionalInfo: ""
          });
        })
        .catch(() => alert("Error adding menu item"));
    }
  };

  return (
    <div className="addmenu-container">
      <div className="addmenu-card">

        <div className="addmenu-header">
          <button
            type="button"
            className="back-btn"
            onClick={() => navigate("/menumanagement")}
          >
            ← Back
          </button>
          <h2>Add Menu Item</h2>
        </div>

        <form onSubmit={handleSubmit}>

          <input
            name="name"
            placeholder="Item Name"
            value={formData.name}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {touched.name && errors.name && (
            <p className="error-text">{errors.name}</p>
          )}

          <textarea
            name="description"
            placeholder="Description"
            value={formData.description}
            onChange={handleChange}
            onBlur={handleBlur}
          />

          <input
            type="text"
            name="keyInged"
            placeholder="Key Ingredients"
            value={formData.keyInged}
            onChange={handleChange}
          />

          <input
            name="price"
            placeholder="Price"
            value={formData.price}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {touched.price && errors.price && (
            <p className="error-text">{errors.price}</p>
          )}

          <input
            type="text"
            name="availableTime"
            placeholder="Available Time (Eg: 10AM - 10PM)"
            value={formData.availableTime}
            onChange={handleChange}
          />

          <input
            name="url"
            placeholder="Image URL"
            value={formData.url}
            onChange={handleChange}
          />

          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
          >
            <option value="">Select Category</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select
            name="dietaryType"
            value={formData.dietaryType}
            onChange={handleChange}
          >
            <option value="">Select Dietary Type</option>
            {dietaryTypes.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          <select
            name="tasteinfo"
            value={formData.tasteinfo}
            onChange={handleChange}
          >
            <option value="">Select Taste</option>
            {tasteInfos.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>

          <textarea
            name="nutrionalInfo"
            placeholder="Nutritional Information"
            value={formData.nutrionalInfo}
            onChange={handleChange}
          />

          <label className="checkbox-label">
            <input
              type="checkbox"
              name="available"
              checked={formData.available}
              onChange={handleChange}
            />
            Available
          </label>

          <button
            type="submit"
            disabled={!isFormValid}
            className="submit-btn"
          >
            Add Menu Item
          </button>

          {success && <p className="success-text">{success}</p>}

        </form>
      </div>
    </div>
  );
}