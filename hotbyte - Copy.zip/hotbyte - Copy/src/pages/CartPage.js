import React, { useEffect, useState } from "react";
import {
  getCart,
  updateQuantity,
  removeItem
} from "../services/userService";
import "../CSS/CartPage.css";
import { useNavigate } from "react-router-dom";

export default function CartPage() {

  const [cart, setCart] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCart();
  }, []);

  const fetchCart = async () => {
    try {
      const res = await getCart();
      console.log("Cart Data:", res.data);
      setCart(res.data);
    } catch (error) {
      console.error("Error loading cart", error);
    }
  };

  const increaseQty = async (item) => {
    try {
      const res = await updateQuantity(item.id, item.quantity + 1);
      setCart(res.data);
    } catch (error) {
      console.error("Increase quantity failed", error);
    }
  };

  const decreaseQty = async (item) => {
    if (item.quantity > 1) {
      try {
        const res = await updateQuantity(item.id, item.quantity - 1);
        setCart(res.data);
      } catch (error) {
        console.error("Decrease quantity failed", error);
      }
    }
  };

  const deleteItem = async (id) => {
    try {
      await removeItem(id);
      fetchCart();
    } catch (error) {
      console.error("Remove item failed", error);
    }
  };

  if (!cart) return <h2 className="loading">Loading Cart...</h2>;

  const items = cart.cartitem || [];

  return (
    <div className="cart-container">

      {/* Header */}
      <div className="cart-header">

        <h1>Your Cart</h1>

        <button
          className="home-btn"
          onClick={() => navigate("/user")}
        >
          🏠 Home
        </button>

      </div>

      {items.length === 0 && (
        <p className="empty-cart">Your cart is empty</p>
      )}

      {items.map((item) => (

        <div className="cart-item" key={item.id}>

          <img
            src={item.menu?.url}
            alt={item.menu?.name}
          />

          <div className="item-details">

            <h3>{item.menu?.name}</h3>

            <p>₹{item.menu?.price}</p>

            <div className="quantity-controls">

              <button onClick={() => decreaseQty(item)}>
                -
              </button>

              <span>{item.quantity}</span>

              <button onClick={() => increaseQty(item)}>
                +
              </button>

            </div>

          </div>

          <div className="item-right">

            <h3>
              ₹{item.menu?.price * item.quantity}
            </h3>

            <button
              className="remove-btn"
              onClick={() => deleteItem(item.id)}
            >
              Remove
            </button>

          </div>

        </div>

      ))}

      {items.length > 0 && (

        <div className="cart-total">

          <h2>Total: ₹{cart.totalprice}</h2>

          <button
            className="checkout-btn"
            onClick={() => navigate("/checkout")}
          >
            Proceed to Checkout
          </button>

        </div>

      )}

    </div>
  );
}