import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { RegisterRestaurant } from "../services/adminService";
import "../CSS/AddRestaurant.css";

export default function AddRestaurant() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    email: "",
    password: "",
    role: "RESTAURANT"
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [success, setSuccess] = useState("");

  const nameregex = /^[A-Za-z\s]+$/;
  const emailregex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordregex = /^.{6,}$/;
  const contactregex = /^[0-9]{10}$/;

  const validate = (field, value) => {
    let error = "";

    if (!value) {
      error = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
    } else {
      if (field === "name" && !nameregex.test(value)) {
        error = "Name should contain only letters";
      }
      if (field === "email" && !emailregex.test(value)) {
        error = "Enter a valid email";
      }
      if (field === "password" && !passwordregex.test(value)) {
        error = "Password must be at least 6 characters";
      }
      if (field === "contact" && !contactregex.test(value)) {
        error = "Contact must contain exactly 10 digits";
      }
    }

    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: validate(name, value)
    }));

    setSuccess("");
  };

  const handleBlur = (e) => {
    const { name } = e.target;

    setTouched((prev) => ({
      ...prev,
      [name]: true
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: validate(name, formData[name])
    }));
  };

  const isFormValid =
    nameregex.test(formData.name) &&
    emailregex.test(formData.email) &&
    passwordregex.test(formData.password) &&
    contactregex.test(formData.contact);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isFormValid) return;

    try {
      const payload = {
        ...formData,
        contact: Number(formData.contact)
      };

      const res = await RegisterRestaurant(payload);
      setSuccess(res.data || "Restaurant added successfully");

      setFormData({
        name: "",
        contact: "",
        email: "",
        password: "",
        role: "RESTAURANT"
      });
      setTouched({});
      setErrors({});

      setTimeout(() => {
        navigate("/managerestaurants");
      }, 1500);
    } catch (error) {
      console.error("Add restaurant error:", error);
      alert(error?.response?.data || "Failed to add restaurant");
    }
  };

  return (
    <div className="addrestaurant-container">
      <div className="addrestaurant-card">
        <button
          className="back-btn"
          onClick={() => navigate("/managerestaurants")}
        >
          ← Back
        </button>

        <h2 className="addrestaurant-title">Add New Restaurant</h2>

        <form onSubmit={handleSubmit}>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addrestaurant-input"
          />
          {touched.name && errors.name && (
            <p className="error-text">{errors.name}</p>
          )}

          <label>Contact:</label>
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addrestaurant-input"
          />
          {touched.contact && errors.contact && (
            <p className="error-text">{errors.contact}</p>
          )}

          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addrestaurant-input"
          />
          {touched.email && errors.email && (
            <p className="error-text">{errors.email}</p>
          )}

          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addrestaurant-input"
          />
          {touched.password && errors.password && (
            <p className="error-text">{errors.password}</p>
          )}

          <button
            type="submit"
            disabled={!isFormValid}
            className="addrestaurant-btn"
          >
            Add Restaurant
          </button>

          {success && <p className="success-text">{success}</p>}
        </form>
      </div>
    </div>
  );
}