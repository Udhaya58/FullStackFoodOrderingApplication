import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  getAllMenu,
  getMenuByName,
  getFilterMenu
} from "../services/userService";
import "../CSS/UserDashboard.css";

export default function UserDashboard() {

  const navigate = useNavigate();

  const [menu, setMenu] = useState([]);
  const [menuName, setMenuName] = useState("");
  const [errMessage, setErrMessage] = useState("");

  const [menuForm, setMenuForm] = useState({
    category: "",
    dietary: "",
    priceRange: ""
  });

  useEffect(() => {
    getAllMenus();
  }, []);

 const getAllMenus = async () => {
  try {
    const res = await getAllMenu();
    console.log("API Response:", res.data);
    setMenu(res.data);
  } catch (error) {
    console.error(error);
  }
};

  const getMenuByNames = async () => {
    try {
      const res = await getMenuByName(menuName);
      const result = res.data;

      setMenu(result);

      if (!result || result.length === 0) {
        setErrMessage("Match Not Found");
        getAllMenus();
      } else {
        setErrMessage("");
      }
    } catch (error) {
      console.error("Search error:", error);
    }
  };

  const applyFilters = async (e) => {
    e.preventDefault();

    let { category, dietary, priceRange } = menuForm;

    category = category?.trim() || "";
    dietary = dietary?.trim() || "";

    let minPrice = 0;
    let maxPrice = 100000;

    if (priceRange) {
      const [min, max] = priceRange.split("-").map(Number);
      minPrice = min;
      maxPrice = max;
    }

    try {
      const res = await getFilterMenu(category, dietary, minPrice, maxPrice);
      const filteredMenu = res.data;

      setMenu(filteredMenu);

      if (!filteredMenu || filteredMenu.length === 0) {
        setErrMessage("No matching menu found.");
      } else {
        setErrMessage("");
      }
    } catch (error) {
      console.error("Filter error:", error);
    }
  };

  const resetFilters = () => {
    setMenuForm({
      category: "",
      dietary: "",
      priceRange: ""
    });

    setErrMessage("");
    getAllMenus();
  };

  const logout = () => {
    localStorage.removeItem("token"); 

    navigate("/");
  };

  return (
    <div className="user-dashboard">

      
      <nav className="navbar">
        <div className="logo">🍽️ HotByte</div>

        <ul className="nav-links">
          <li><button onClick={() => navigate("/user")}>Home</button></li>
          <li><button onClick={() => navigate("/cart")}>Cart</button></li>
          <li><button onClick={() => navigate("/orderpage")}>Orders</button></li>
          <li><button onClick={logout}>Logout</button></li>
        </ul>
      </nav>


     
      <div className="search-filter-section">

        <div className="search-bar">
          <input
            type="text"
            placeholder="🔍 Search dishes or restaurants..."
            className="search-input"
            value={menuName}
            onChange={(e) => setMenuName(e.target.value)}
          />

          <button className="search-btn" onClick={getMenuByNames}>
            Search
          </button>
        </div>


       
        <div className="filters">

          <form className="filter-form" onSubmit={applyFilters}>

            <div className="filter-group">
              <label>Category</label>

              <select
                value={menuForm.category}
                onChange={(e) =>
                  setMenuForm({ ...menuForm, category: e.target.value })
                }
              >
                <option value="">All</option>
                <option value="MAIN_COURSE">Main Course</option>
                <option value="DESSERTS">Desserts</option>
                <option value="BEVERAGES">Beverages</option>
                <option value="SNACKS">Snacks</option>
                <option value="SALADS">Salads</option>
                <option value="SOUPS">Soups</option>
              </select>
            </div>


            <div className="filter-group">
              <label>Type</label>

              <select
                value={menuForm.dietary}
                onChange={(e) =>
                  setMenuForm({ ...menuForm, dietary: e.target.value })
                }
              >
                <option value="">All</option>
                <option value="VEG">Veg</option>
                <option value="NONVEG">Non-Veg</option>
              </select>
            </div>


            <div className="filter-group">
              <label>Price</label>

              <select
                value={menuForm.priceRange}
                onChange={(e) =>
                  setMenuForm({ ...menuForm, priceRange: e.target.value })
                }
              >
                <option value="">All</option>
                <option value="0-100">Below ₹100</option>
                <option value="100-200">₹100 - ₹200</option>
                <option value="200-500">₹200 - ₹500</option>
                <option value="500-100000">Above ₹500</option>
              </select>
            </div>


            <div className="filter-actions">
              <button type="submit" className="search-btn">
                Apply Filters
              </button>

              <button
                type="button"
                className="search-btn"
                onClick={resetFilters}
              >
                Reset
              </button>
            </div>

          </form>

        </div>

      </div>


     
      <h1>{errMessage}</h1>

      <div className="menu-grid">

        {menu.map((menus) => (
          <div
            className="menu-card"
            key={menus.id}
            onClick={() => navigate(`/product/${menus.id}`)}
          >

            <img src={menus.url} alt="menu" />

            <div className="menu-info">
              <h3>{menus.name}</h3>

              <p>
                <strong>Description:</strong> {menus.description}
              </p>

              <p>
                <strong>Restaurant:</strong> {menus.restaurant?.name}
              </p>

              <p>
                <strong>Price:</strong> ₹{menus.price}
              </p>

            </div>

          </div>
        ))}

      </div>

    </div>
  );
}