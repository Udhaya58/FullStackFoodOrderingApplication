import React from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/ManageCustomer.css";

export default function ManageCustomer() {
  const navigate = useNavigate();

  return (
    <div className="manageuser-page">
      <div className="manageuser-topbar">
        <button
          className="back-btn"
          onClick={() => navigate("/usermanagement")}
        >
          Back
        </button>
      </div>

      <div className="manageuser-card-wrapper">
        <div className="manageuser-header">
          <h1>Manage the User</h1>
          <p>Quick actions to Add and Delete Users</p>
        </div>

        <div className="manageuser-actions">
          <div
            className="action-card"
            onClick={() => navigate("/addcustomer")}
          >
            <div className="action-icon">
              <img
                src="https://cdn-icons-png.flaticon.com/512/747/747376.png"
                alt="Add User"
              />
            </div>
            <button className="action-btn">Add</button>
            <p>Add the customer</p>
          </div>

          <div
            className="action-card"
            onClick={() => navigate("/deletecustomer")}
          >
            <div className="action-icon">
              <img
                src="https://cdn-icons-png.flaticon.com/512/1214/1214428.png"
                alt="Delete User"
              />
            </div>
            <button className="action-btn">Delete</button>
            <p>Delete the Customer</p>
          </div>
        </div>
      </div>
    </div>
  );
}