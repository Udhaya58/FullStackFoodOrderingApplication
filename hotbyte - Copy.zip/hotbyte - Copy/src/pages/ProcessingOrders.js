import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  processingOrders,
  outForDelivery
} from "../services/restaurantService";
import "../CSS/ProcessingOrders.css";

export default function ProcessingOrders() {

  const [orderList, setOrderList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchProcessingOrders();
  }, []);

  const fetchProcessingOrders = async () => {
    try {
      const res = await processingOrders();
      setOrderList(res.data);
    } catch (error) {
      alert("Failed to fetch processing orders");
    }
  };

  const handleOutForDelivery = async (orderId) => {
    if (window.confirm("Send this order to Out For Delivery?")) {
      try {
        await outForDelivery(orderId);
        alert("Order moved to Out For Delivery");
        fetchProcessingOrders();
      } catch (error) {
        alert("Failed to update order status");
      }
    }
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    return new Date(dateTime).toLocaleString();
  };

  return (
    <div className="processing-container">

      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/ordermanagement")}
        >
          ← Back
        </button>

        <h2>Processing Orders</h2>
      </div>

      <div className="processing-list">

        {orderList.length === 0 ? (
          <p className="empty-text">No processing orders found.</p>
        ) : (
          orderList.map((order) => (

            <div className="processing-card" key={order.id}>

              <h3>Order ID: {order.id}</h3>

              <p>
                <strong>Customer:</strong>{" "}
                {order.user?.username || order.user?.name || "N/A"}
              </p>

              <p>
                <strong>Shipping Address:</strong>{" "}
                {order.shippingAddress || order.address || "N/A"}
              </p>

              <p>
                <strong>Order Time:</strong>{" "}
                {formatDateTime(order.orderTime || order.createdAt)}
              </p>

              <p>
                <strong>Payment:</strong>{" "}
                {order.paymentMethod || "N/A"}
              </p>

              <p>
                <strong>Total:</strong> ₹
                {order.totalAmount || order.totalPrice || 0}
              </p>

              <p>
                <strong>Status:</strong>{" "}
                <span className="processing-status">
                  {order.status}
                </span>
              </p>

              <div className="items-section">
                <p><strong>Items:</strong></p>

                <ul>
                  {order.orderItems && order.orderItems.length > 0 ? (
                    order.orderItems.map((item, index) => (
                      <li key={item.id || index}>
                        {item.menu?.name || item.menu?.itemName || item.itemName}
                        {" — "}₹{item.price} x {item.quantity}
                      </li>
                    ))
                  ) : (
                    <li>No items available</li>
                  )}
                </ul>
              </div>

              <button
                className="delivery-btn"
                onClick={() => handleOutForDelivery(order.id)}
              >
                Out For Delivery
              </button>

            </div>

          ))
        )}

      </div>

    </div>
  );
}