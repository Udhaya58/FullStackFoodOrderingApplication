import React from 'react'
import { useNavigate } from 'react-router-dom'
import "../CSS/Menu.css"

export default function Menu() {
    const navigate = useNavigate()
  return (
     <div className="menu-container">

      {/* Top Header Section */}
      <div className="menu-header">
        <h2 className="menu-title">Manage Your Menu</h2>

        <button
          className="home-btn"
          onClick={() => navigate("/restaurant")}
        >
          🏠 Home
        </button>
      </div>

      <p className="menu-subtitle">
        Quick actions to manage, update and control availability of your menu items.
      </p>

      <div className="menu-grid">

        <div className="menu-card" onClick={() => navigate("/addmenu")}>
          <div className="menu-icon">➕</div>
          <h3>Add Menu Item</h3>
          <p>Create and list a new food item.</p>
        </div>

        <div className="menu-card" onClick={() => navigate("/editmenu")}>
          <div className="menu-icon">✏️</div>
          <h3>Edit Menu</h3>
          <p>Update existing food items and prices.</p>
        </div>

        <div className="menu-card" onClick={() => navigate("/instock")}>
          <div className="menu-icon success">✔</div>
          <h3>In Stock</h3>
          <p>View available menu items.</p>
        </div>

        <div className="menu-card" onClick={() => navigate("/outofstock")}>
          <div className="menu-icon danger">✖</div>
          <h3>Out of Stock</h3>
          <p>View unavailable menu items.</p>
        </div>

      </div>
    </div>
  );
}
