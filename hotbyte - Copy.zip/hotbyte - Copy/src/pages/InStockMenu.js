import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {  instock, makeOutOfStock } from "../services/restaurantService";
import "../CSS/InStockMenu.css";

export default function InStockMenu() {
  const [menuList, setMenuList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const res = await instock();
      const inStockItems = res.data
      setMenuList(inStockItems);
    } catch (error) {
      alert("Failed to fetch menu items");
    }
  };

  const handleMarkOutOfStock = async (id) => {
    if (window.confirm("Are you sure you want to mark this item as Out of Stock?")) {
      try {
        await makeOutOfStock(id);
        alert("Item marked as Out of Stock");
        fetchMenu(); 
      } catch (error) {
        alert("Failed to update status");
      }
    }
  };

  return (
    <div className="instock-container">
      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/menumanagement")}
        >
          ← Back
        </button>
        <h2>In Stock Menu Items</h2>
      </div>

      <div className="menu-grid">
        {menuList.length === 0 ? (
          <p className="empty-text">No in-stock items found.</p>
        ) : (
          menuList.map(item => (
            <div className="menu-card" key={item.id}>
              {item.url && <img src={item.url} alt={item.name} className="menu-image" />}
              <div className="menu-content">
                <h3>{item.name}</h3>
                <p className="description">{item.description}</p>
                <p><strong>Category:</strong> {item.category}</p>
                <p><strong>Price:</strong> ₹{item.price}</p>
                <p><strong>Diet:</strong> {item.dietaryType}</p>
                <p><strong>Taste:</strong> {item.tasteinfo}</p>
                <p><strong>Status:</strong> <span className="available">In Stock</span></p>

                <button
                  className="outstock-btn"
                  onClick={() => handleMarkOutOfStock(item.id)}
                >
                  Mark Out of Stock
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}