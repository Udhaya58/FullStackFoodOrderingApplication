import React, { useEffect, useState } from "react";
import { getCart, checkout } from "../services/userService";
import { useNavigate } from "react-router-dom";
import "../CSS/CheckoutPage.css";

export default function CheckoutPage() {

  const navigate = useNavigate();

  const [cart, setCart] = useState(null);

  const [order, setOrder] = useState({
    shippingAddress: "",
    paymentMethod: "COD"
  });

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    try {
      const res = await getCart();
      setCart(res.data);
    } catch (error) {
      console.error("Error loading cart", error);
    }
  };

  const handleChange = (e) => {
    setOrder({
      ...order,
      [e.target.name]: e.target.value
    });
  };

  const placeOrder = async (e) => {
    e.preventDefault();

    try {
        const res = await checkout(order);

         const orderId=res.data.id;

        alert("Order placed successfully!");

        navigate(`/order-summary/${orderId}`);

    } catch (error) {
      console.error("Checkout failed", error);
      alert("Failed to place order");
    }
  };

  if (!cart) return <h2 className="loading">Loading...</h2>;

  return (
    <div className="checkout-container">

      <h1>Checkout</h1>

      <div className="checkout-grid">

        {/* Shipping Details */}
        <div className="shipping-section">

          <h2>Shipping Details</h2>

          <form onSubmit={placeOrder}>

            <label>Shipping Address</label>
            <textarea
              name="shippingAddress"
              placeholder="Enter delivery address"
              value={order.shippingAddress}
              onChange={handleChange}
              required
            />

            <label>Payment Method</label>

            <select
              name="paymentMethod"
              value={order.paymentMethod}
              onChange={handleChange}
            >
              <option value="COD">Cash On Delivery</option>
              <option value="UPI">UPI</option>
              <option value="CARD">Card</option>
            </select>

            <button type="submit" className="place-order-btn">
              Place Order
            </button>

          </form>

        </div>

        {/* Order Summary */}
        <div className="order-summary">

          <h2>Order Summary</h2>

          {cart.cartitem?.map((item) => (

            <div className="summary-item" key={item.id}>

              <span>{item.menu?.name} × {item.quantity}</span>

              <span>₹{item.price}</span>

            </div>

          ))}

          <hr />

          <h3>Total: ₹{cart.totalprice}</h3>

        </div>

      </div>

    </div>
  );
}