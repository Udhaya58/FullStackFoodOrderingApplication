import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllRestaurants, deleteRestaurant } from "../services/adminService";
import "../CSS/DeleteRestaurant.css";

export default function DeleteRestaurant() {
  const [restaurantList, setRestaurantList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const res = await getAllRestaurants();
      setRestaurantList(res.data);
    } catch (error) {
      alert("Failed to fetch restaurants");
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this restaurant?");
    if (!confirmDelete) return;

    try {
      await deleteRestaurant(id);
      alert("Restaurant deleted successfully");
      fetchRestaurants();
    } catch (error) {
      alert("Failed to delete restaurant");
    }
  };

  return (
    <div className="deleterestaurant-page">
      <div className="deleterestaurant-wrapper">

        <button
          className="back-btn"
          onClick={() => navigate("/managerestaurants")}
        >
          Back
        </button>

        <h2 className="deleterestaurant-title">All Restaurants</h2>

        <div className="restaurant-grid">
          {restaurantList.length === 0 ? (
            <p className="empty-text">No restaurants found</p>
          ) : (
            restaurantList.map((res) => (
              <div className="restaurant-card" key={res.id}>
                <h3>{res.name}</h3>

                <p>
                  <strong>Contact:</strong> {res.contact}
                </p>

                <p>
                  <strong>Email:</strong> {res.email}
                </p>

                

                <button
                  className="delete-btn"
                  onClick={() => handleDelete(res.id)}
                >
                  Delete
                </button>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
}