import React from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/AdminDashboard.css";

export default function AdminDashboard() {

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div className="admin-container">

      {/* Top Header */}
      <div className="admin-topbar">
        <h2>Admin Dashboard</h2>
      </div>

      <div className="admin-body">

        {/* Sidebar */}
        <div className="admin-sidebar">
          <h2 className="admin-logo">HotByte</h2>

          <p onClick={() => navigate("/admin")}>Dashboard</p>
          <p onClick={() => navigate("/usermanagement")}>User management</p>
          <p onClick={() => navigate("/adminmenu")}>Menu management</p>
          <p onClick={handleLogout}>Logout</p>
        </div>

        {/* Main Content */}
        <div className="admin-main">

          <div className="admin-welcome">
            <h1>Welcome to Admin Panel</h1>
          </div>

        </div>

      </div>

    </div>
  );
}