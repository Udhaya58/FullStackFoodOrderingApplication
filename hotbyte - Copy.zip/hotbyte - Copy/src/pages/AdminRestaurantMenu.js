import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  getRestaurantMenusById,
  deleteMenuByAdmin
} from "../services/adminService";
import "../CSS/AdminRestaurantMenu.css";

export default function AdminRestaurantMenu() {
  const [menuList, setMenuList] = useState([]);
  const { restaurantId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const restaurantName = location.state?.restaurantName || "Restaurant Menu";

  useEffect(() => {
    fetchMenus();
  }, [restaurantId]);

  const fetchMenus = async () => {
    try {
      const res = await getRestaurantMenusById(restaurantId);
      setMenuList(res.data);
    } catch (error) {
      alert("Failed to fetch menu items");
    }
  };

  const handleDelete = async (menuId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this menu item?");
    if (!confirmDelete) return;

    try {
      await deleteMenuByAdmin(menuId);
      alert("Menu item deleted successfully");
      fetchMenus();
    } catch (error) {
      alert("Failed to delete menu item");
    }
  };

  const handleUpdate = (menuId) => {
    navigate(`/adminupdatemenu/${menuId}`);
  };

  return (
    <div className="adminrestaurantmenu-container">
      <div className="adminrestaurantmenu-top">
        <button
          className="back-btn"
          onClick={() => navigate("/adminmenu")}
        >
          ← Back
        </button>

        <h2>{restaurantName}</h2>
      </div>

      <div className="adminrestaurantmenu-grid">
        {menuList.length === 0 ? (
          <p className="empty-text">No menu items found.</p>
        ) : (
          menuList.map((item) => (
            <div className="adminmenu-card" key={item.id}>
              {item.url && (
                <img
                  src={item.url}
                  alt={item.name}
                  className="adminmenu-image"
                />
              )}

              <div className="adminmenu-content">
                <h3>{item.name}</h3>
                <p className="description">{item.description}</p>
                <p><strong>Category:</strong> {item.category}</p>
                <p><strong>Price:</strong> ₹{item.price}</p>
                <p><strong>Diet:</strong> {item.dietaryType}</p>
                <p><strong>Taste:</strong> {item.tasteinfo}</p>
                <p>
                  <strong>Status:</strong>{" "}
                  <span className={item.available ? "available" : "unavailable"}>
                    {item.available ? "Available" : "Out of Stock"}
                  </span>
                </p>

                <div className="adminmenu-btn-group">
                  <button
                    className="delete-btn"
                    onClick={() => handleUpdate(item.id)}
                  >
                    Update
                  </button>

                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(item.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}