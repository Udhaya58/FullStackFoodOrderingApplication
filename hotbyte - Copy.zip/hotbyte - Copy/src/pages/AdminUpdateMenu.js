import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getMenuById,
  updateMenuByAdmin
} from "../services/adminService";
import "../CSS/AdminUpdateMenu.css";

export default function AdminUpdateMenu() {
  const { menuId } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    dietaryType: "",
    tasteinfo: "",
    url: "",
    available: true
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMenuDetails();
  }, [menuId]);

  const fetchMenuDetails = async () => {
    try {
      const res = await getMenuById(menuId);
      setFormData({
        name: res.data.name || "",
        description: res.data.description || "",
        price: res.data.price || "",
        category: res.data.category || "",
        dietaryType: res.data.dietaryType || "",
        tasteinfo: res.data.tasteinfo || "",
        url: res.data.url || "",
        available: res.data.available ?? true
      });
    } catch (error) {
      alert("Failed to fetch menu details");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const payload = {
        ...formData,
        price: Number(formData.price)
      };

      await updateMenuByAdmin(menuId, payload);
      alert("Menu updated successfully");
      navigate(-1);
    } catch (error) {
      alert("Failed to update menu");
    }
  };

  if (loading) {
    return <p className="update-menu-loading">Loading menu details...</p>;
  }

  return (
    <div className="update-menu-container">
      <div className="update-menu-card">
        <button className="back-btn" onClick={() => navigate(-1)}>
          ← Back
        </button>

        <h2 className="update-menu-title">Update Menu Item</h2>

        <form onSubmit={handleSubmit}>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="update-menu-input"
            required
          />

          <label>Description:</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="update-menu-textarea"
            rows="4"
            required
          />

          <label>Price:</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            className="update-menu-input"
            required
          />

          <label>Category:</label>
          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
            className="update-menu-input"
            required
          >
            <option value="">Select Category</option>
            <option value="STARTERS">STARTERS</option>
            <option value="MAIN_COURSE">MAIN_COURSE</option>
            <option value="DESSERTS">DESSERTS</option>
            <option value="BEVERAGES">BEVERAGES</option>
          </select>

          <label>Dietary Type:</label>
          <select
            name="dietaryType"
            value={formData.dietaryType}
            onChange={handleChange}
            className="update-menu-input"
            required
          >
            <option value="">Select Dietary Type</option>
            <option value="VEG">VEG</option>
            <option value="NON_VEG">NON_VEG</option>
          </select>

          <label>Taste Info:</label>
          <select
            name="tasteinfo"
            value={formData.tasteinfo}
            onChange={handleChange}
            className="update-menu-input"
            required
          >
            <option value="">Select Taste</option>
            <option value="SWEET">SWEET</option>
            <option value="SPICY">SPICY</option>
            <option value="SALTY">SALTY</option>
            <option value="BITTER">BITTER</option>
          </select>

          <label>Image URL:</label>
          <input
            type="text"
            name="url"
            value={formData.url}
            onChange={handleChange}
            className="update-menu-input"
          />

          <label className="checkbox-label">
            <input
              type="checkbox"
              name="available"
              checked={formData.available}
              onChange={handleChange}
            />
            Available
          </label>

          <button type="submit" className="update-menu-btn">
            Update Menu
          </button>
        </form>
      </div>
    </div>
  );
}