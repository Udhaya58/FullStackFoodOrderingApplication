import React, { useEffect, useState } from "react";
import { getUserOrders } from "../services/userService";
import { useNavigate } from "react-router-dom";
import "../CSS/OrdersPage.css";

export default function OrdersPage() {

  const [orders, setOrders] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {

      const res = await getUserOrders();

      console.log("Orders:", res.data);

      setOrders(res.data);

    } catch (error) {
      console.error("Error loading orders", error);
    }
  };

  return (

    <div className="orders-container">

      <div className="orders-header">

        <h1>My Orders</h1>

        <button
          className="home-btn"
          onClick={() => navigate("/user")}
        >
          🏠 Home
        </button>

      </div>

      {orders.length === 0 && <p>No orders found</p>}

      {orders.map((order) => (

        <div
          key={order.id}
          className="order-card"
          onClick={() => navigate(`/order-summary/${order.id}`)}
        >

          <h3>{order.restaurant?.name}</h3>

          <p><strong>Order ID:</strong> {order.id}</p>

          <p>
            <strong>Items:</strong>{" "}
            {order.orderitem?.map((item) =>
              item.menu?.name
            ).join(", ")}
          </p>

          <p><strong>Total:</strong> ₹{order.totalAmount}</p>

          <p><strong>Payment:</strong> {order.paymentMethod}</p>

          <p><strong>Status:</strong> {order.status}</p>

          <p><strong>Address:</strong> {order.shippingAddress}</p>

          <p>
            <strong>Order Time:</strong>{" "}
            {new Date(order.orderTime).toLocaleString()}
          </p>

        </div>

      ))}

    </div>

  );
}