import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { restaurantOrderHistory } from "../services/restaurantService";
import "../CSS/OrderHistory.css";

export default function OrderHistory() {
  const [orderList, setOrderList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrderHistory();
  }, []);

  const fetchOrderHistory = async () => {
    try {
      const res = await restaurantOrderHistory();
      setOrderList(res.data);
    } catch (error) {
      alert("Failed to fetch order history");
    }
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    return new Date(dateTime).toLocaleString();
  };

  return (
    <div className="orderhistory-container">
      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/restaurant")}
        >
          ← Back
        </button>
        <h2>Order History</h2>
      </div>

      <div className="orderhistory-list">
        {orderList.length === 0 ? (
          <p className="empty-text">No order history found.</p>
        ) : (
          orderList.map((order) => (
            <div className="orderhistory-card" key={order.id}>
              <h3>Order ID: {order.id}</h3>

              <p>
                <strong>Customer:</strong>{" "}
                {order.user?.name || "N/A"}
              </p>

              <p>
                <strong>Customer Email:</strong>{" "}
                {order.user?.email || "N/A"}
              </p>

              <p>
                <strong>Customer Contact:</strong>{" "}
                {order.user?.contact || "N/A"}
              </p>

              <p>
                <strong>Shipping Address:</strong>{" "}
                {order.shippingAddress || "N/A"}
              </p>

              <p>
                <strong>Payment Method:</strong>{" "}
                {order.paymentMethod || "N/A"}
              </p>

              <p>
                <strong>Total Amount:</strong> ₹{order.totalAmount || 0}
              </p>

              <p>
                <strong>Order Time:</strong>{" "}
                {formatDateTime(order.orderTime)}
              </p>

              <p>
                <strong>Status:</strong>{" "}
                <span className="history-status">{order.status}</span>
              </p>

              <div className="items-section">
                <p><strong>Items:</strong></p>
                <ul>
                  {order.orderitem && order.orderitem.length > 0 ? (
                    order.orderitem.map((item, index) => (
                      <li key={item.id || index}>
                        {item.menu?.name || "Menu Item"} — ₹{item.price} x {item.quantity}
                      </li>
                    ))
                  ) : (
                    <li>No items available</li>
                  )}
                </ul>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}