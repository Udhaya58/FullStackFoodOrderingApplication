import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  outForDeliveryOrders,
  markDelivered
} from "../services/restaurantService";
import "../CSS/OutForDeliveryOrders.css";

export default function OutForDeliveryOrders() {
  const [orderList, setOrderList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOutForDeliveryOrders();
  }, []);

  const fetchOutForDeliveryOrders = async () => {
    try {
      const res = await outForDeliveryOrders();
      setOrderList(res.data);
    } catch (error) {
      alert("Failed to fetch out for delivery orders");
    }
  };

  const handleDelivered = async (orderId) => {
    if (window.confirm("Are you sure this order is delivered?")) {
      try {
        await markDelivered(orderId);
        alert("Order marked as Delivered");
        fetchOutForDeliveryOrders();
      } catch (error) {
        alert("Failed to update order status");
      }
    }
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    return new Date(dateTime).toLocaleString();
  };

  return (
    <div className="outdelivery-container">
      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/ordermanagement")}
        >
          ← Back
        </button>
        <h2>Out For Delivery Orders</h2>
      </div>

      <div className="outdelivery-list">
        {orderList.length === 0 ? (
          <p className="empty-text">No out for delivery orders found.</p>
        ) : (
          orderList.map((order) => (
            <div className="outdelivery-card" key={order.id}>
              <h3>Order ID: {order.id}</h3>

              <p>
                <strong>Customer:</strong>{" "}
                {order.user?.username || order.user?.name || "N/A"}
              </p>

              <p>
                <strong>Shipping Address:</strong>{" "}
                {order.shippingAddress || order.address || "N/A"}
              </p>

              <p>
                <strong>Order Time:</strong>{" "}
                {formatDateTime(order.orderTime || order.createdAt)}
              </p>

              <p>
                <strong>Payment:</strong>{" "}
                {order.paymentMethod || "N/A"}
              </p>

              <p>
                <strong>Total:</strong> ₹
                {order.totalAmount || order.totalPrice || 0}
              </p>

              <p>
                <strong>Status:</strong>{" "}
                <span className="outdelivery-status">{order.status}</span>
              </p>

              <div className="items-section">
                <p><strong>Items:</strong></p>
                <ul>
                  {order.orderItems && order.orderItems.length > 0 ? (
                    order.orderItems.map((item, index) => (
                      <li key={item.id || index}>
                        {item.menu?.name || item.menu?.itemName || item.itemName}
                        {" — "}₹{item.price} x {item.quantity}
                      </li>
                    ))
                  ) : (
                    <li>No items available</li>
                  )}
                </ul>
              </div>

              <button
                className="delivered-btn"
                onClick={() => handleDelivered(order.id)}
              >
                Delivered
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}