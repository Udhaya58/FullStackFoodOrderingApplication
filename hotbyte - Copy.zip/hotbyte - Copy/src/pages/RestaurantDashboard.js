import React from 'react'
import { useNavigate } from 'react-router-dom';
import '../CSS/RestaurantDashboard.css'

export default function RestaurantDashboard() {

  const navigate = useNavigate();

  const handleLogout = () => {

   
    localStorage.removeItem("token");

  
    navigate("/");

  };

  return (
    <div className="dashboard-container">

      <div className="topbar">
        <h2>Restaurant Dashboard</h2>

        <div className="profile">
          <img
            src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
            alt="profile"
            className="avatar"
          />
          <span>Welcome</span>
        </div>
      </div>

      <div className="dashboard-body">

        <div className="sidebar">
          <h2 className="logo">HotByte</h2>

          <p onClick={() => navigate("/restaurant")}>Dashboard</p>
          <p onClick={() => navigate("/menumanagement")}>Menu Management</p>
          <p onClick={() => navigate("/ordermanagement")}>Orders</p>
          <p onClick={() => navigate("/orderhistory")}>Order History</p>
          <p onClick={handleLogout}>Logout</p>
        </div>

        <div className="main-content">
          <div className="welcome-card">
            <h1>Welcome to Restaurant Panel</h1>
          </div>
        </div>

      </div>

    </div>
  );
}