import React from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/RestaurantManagement.css";

export default function RestaurantManagement() {
  const navigate = useNavigate();

  return (
    <div className="managerestaurant-page">
      <div className="managerestaurant-topbar">
        <button
          className="back-btn"
          onClick={() => navigate("/usermanagement")}
        >
          Back
        </button>
      </div>

      <div className="managerestaurant-card-wrapper">
        <div className="managerestaurant-header">
          <h1>Manage the Restaurant</h1>
          <p>Quick actions to Add and Delete Restaurants</p>
        </div>

        <div className="managerestaurant-actions">
          <div
            className="action-card"
            onClick={() => navigate("/addrestaurant")}
          >
            <div className="action-icon">
              <img
                src="https://cdn-icons-png.flaticon.com/512/3075/3075977.png"
                alt="Add Restaurant"
              />
            </div>
            <button className="action-btn">Add</button>
            <p>Add the restaurant</p>
          </div>

          <div
            className="action-card"
            onClick={() => navigate("/deleterestaurant")}
          >
            <div className="action-icon">
              <img
                src="https://cdn-icons-png.flaticon.com/512/1214/1214428.png"
                alt="Delete Restaurant"
              />
            </div>
            <button className="action-btn">Delete</button>
            <p>Delete the restaurant</p>
          </div>
        </div>
      </div>
    </div>
  );
}