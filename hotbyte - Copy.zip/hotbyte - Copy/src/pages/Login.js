import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { loginUser } from '../services/authService';
import { getUserRole, setToken } from '../util/authUtil';
import "../CSS/Login.css";

export default function Login() {
    const navigate = useNavigate();

    const[formData,setFormData]=useState(
        {
            email:"",
            password:""
        }
    )
    const[errors,setErrors]=useState({});
    const[touched,setTouched]=useState({});
    const[success,setSuccess]=useState("");

    const emailregex=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordregex=/^.{6,}$/;

    const validate=(field,value)=>{
        let error="";

        if(field=="email" && !emailregex.test(value)){
            error="Only letters allowed";

        }

        if(field=="password" && !passwordregex.test(value)){
            error="Minimum 6 characters required";
        }

        return error
    };
    const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({ ...formData, [name]: value });

    const error = validate(name, value);
    setErrors({ ...errors, [name]: error });

    setSuccess("");
};

    const handleBlur=(e)=>{
        setTouched({...touched,[e.target.name]:true});
    };

    const isFormValid=
        emailregex.test(formData.email)&&
        passwordregex.test(formData.password);


    const handleSubmit=(e)=>{
        e.preventDefault();

        if(isFormValid){
            loginUser(formData)
            .then(res=>{
                const token=res.data.token;
                setToken(token);

                const role=getUserRole();
                console.log("Decoded role",role);

                if(role==="USER"){
                    navigate("/user");
                }
                else if(role==="RESTAURANT"){
                    navigate("/restaurant");
                }
                else if(role=="ADMIN"){
                    navigate("/admin");
                }
                setSuccess("Login Successful")
            })
            .catch(err=>{
                alert("Invalid Credentials")
            });
        }
    }

return (
  <div className="login-container">
    <div className="login-card">
      <h2 className="login-title">HotByte</h2>

      <form onSubmit={handleSubmit}>

        <input
          type="text"
          name="email"
          placeholder="Enter Email"
          value={formData.email}
          onChange={handleChange}
          onBlur={handleBlur}
          className="login-input"
        />
        {touched.email && errors.email && (
          <p className="error-text">{errors.email}</p>
        )}

        <input
          type="password"
          name="password"
          placeholder="Enter Password"
          value={formData.password}
          onChange={handleChange}
          onBlur={handleBlur}
          className="login-input"
        />
        {touched.password && errors.password && (
          <p className="error-text">{errors.password}</p>
        )}

        <button
          type="submit"
          disabled={!isFormValid}
          className="login-btn"
        >
          LOGIN
        </button>

        <div className="register-text">
          <span>New here? </span>
              <span
                className="register-link"
                style={{ cursor: "pointer" }}
                onClick={() => navigate("/register")}>Register
            </span>
        
        </div>

      </form>
    </div>
  </div>
)
}