import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllUsers, deleteUser } from "../services/adminService";
import "../CSS/DeleteCustomer.css";

export default function DeleteCustomer() {
  const [userList, setUserList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await getAllUsers();
      setUserList(res.data);
    } catch (error) {
      alert("Failed to fetch users");
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this user?");
    if (!confirmDelete) return;

    try {
      await deleteUser(id);
      alert("User deleted successfully");
      fetchUsers();
    } catch (error) {
      alert("Failed to delete user");
    }
  };

  return (
    <div className="deleteuser-page">
      <div className="deleteuser-wrapper">
        <button
          className="deleteuser-back-btn"
          onClick={() => navigate("/managecustomers")}
        >
          Back
        </button>

        <h2 className="deleteuser-title">All Registered Users</h2>

        <div className="deleteuser-grid">
          {userList.length === 0 ? (
            <p className="empty-text">No users found.</p>
          ) : (
            userList.map((user) => (
              <div className="deleteuser-card" key={user.id}>
                <h3>{user.name}</h3>
                <p>
                  <strong>Contact:</strong> {user.contact}
                </p>
                <p>
                  <strong>Email:</strong> {user.email}
                </p>

                <button
                  className="delete-btn"
                  onClick={() => handleDelete(user.id)}
                >
                  Delete
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}