import React from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/OrderManagement.css";

export default function OrderManagement() {

  const navigate = useNavigate();

  return (
    <div className="ordermanagement-container">

      <div className="header">
        <h1>Manage Your Orders</h1>
        <p>Quick manage to the orders which is currently required</p>
      </div>

      <button
        className="home-btn"
        onClick={() => navigate("/restaurant")}
      >
        🏠 Home
      </button>

      <div className="orders-grid">

        
        <div className="order-card">
          <div className="icon">⏳</div>

          <button
            className="order-btn"
            onClick={() => navigate("/pendingorders")}
          >
            ➕ Pending Orders
          </button>

          <p>Can view and accept the new orders</p>
        </div>


     
        <div className="order-card">
          <div className="icon">👨‍🍳</div>

          <button
            className="order-btn"
            onClick={() => navigate("/processingorders")}
          >
            ✏️ Processing Orders
          </button>

          <p>Can view and update the order to delivered</p>
        </div>


        {/* Out For Delivery */}
        <div className="order-card">
          <div className="icon">🚚</div>

          <button
            className="order-btn"
            onClick={() => navigate("/outfordeliveryorders")}
          >
            ✏️ Out For Delivery Orders
          </button>

          <p>Can view the Out For Delivery Orders</p>
        </div>

      </div>

    </div>
  );
}