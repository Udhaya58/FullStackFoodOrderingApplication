import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { RegisterUser } from "../services/adminService";
import "../CSS/AddCustomer.css";

export default function AddCustomer() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    contact: "",
    role: "USER"
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [success, setSuccess] = useState("");

  const nameregex = /^[A-Za-z\s]+$/;
  const emailregex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordregex = /^.{6,}$/;
  const contactregex = /^[0-9]{10}$/;

  const validate = (field, value) => {
    let error = "";

    if (!value) {
      error = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
    } else {
      if (field === "name" && !nameregex.test(value)) {
        error = "Name should contain only letters";
      }

      if (field === "email" && !emailregex.test(value)) {
        error = "Enter a valid email";
      }

      if (field === "password" && !passwordregex.test(value)) {
        error = "Password must be at least 6 characters";
      }

      if (field === "contact" && !contactregex.test(value)) {
        error = "Contact must contain exactly 10 digits";
      }
    }

    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value
    });

    const error = validate(name, value);
    setErrors({
      ...errors,
      [name]: error
    });

    setSuccess("");
  };

  const handleBlur = (e) => {
    const { name } = e.target;

    setTouched({
      ...touched,
      [name]: true
    });

    const error = validate(name, formData[name]);
    setErrors({
      ...errors,
      [name]: error
    });
  };

  const isFormValid =
    nameregex.test(formData.name) &&
    emailregex.test(formData.email) &&
    passwordregex.test(formData.password) &&
    contactregex.test(formData.contact);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isFormValid) {
      RegisterUser(formData)
        .then((res) => {
          setSuccess("User added successfully");
          setFormData({
            name: "",
            email: "",
            password: "",
            contact: "",
            role: "USER"
          });
          setTouched({});
          setErrors({});

          setTimeout(() => {
            navigate("/managecustomers");
          }, 1500);
        })
        .catch((error) => {
          alert("Failed to add user");
        });
    }
  };

  return (
    <div className="addcustomer-container">
      <div className="addcustomer-card">
        <button
          className="back-btn"
          onClick={() => navigate("/managecustomers")}
        >
          ← Back
        </button>

        <h2 className="addcustomer-title">Add New User</h2>

        <form onSubmit={handleSubmit}>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addcustomer-input"
          />
          {touched.name && errors.name && (
            <p className="error-text">{errors.name}</p>
          )}

          <label>Contact:</label>
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addcustomer-input"
          />
          {touched.contact && errors.contact && (
            <p className="error-text">{errors.contact}</p>
          )}

          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addcustomer-input"
          />
          {touched.email && errors.email && (
            <p className="error-text">{errors.email}</p>
          )}

          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            onBlur={handleBlur}
            className="addcustomer-input"
          />
          {touched.password && errors.password && (
            <p className="error-text">{errors.password}</p>
          )}

          <button
            type="submit"
            disabled={!isFormValid}
            className="addcustomer-btn"
          >
            Add User
          </button>

          {success && <p className="success-text">{success}</p>}
        </form>
      </div>
    </div>
  );
}