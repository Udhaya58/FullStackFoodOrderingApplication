import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  pendingOrders,
  orderProcessing,
  cancelOrder
} from "../services/restaurantService";
import "../CSS/PendingOrders.css";

export default function PendingOrders() {
  const [orderList, setOrderList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPendingOrders();
  }, []);

  const fetchPendingOrders = async () => {
    try {
      const res = await pendingOrders();
      setOrderList(res.data);
    } catch (error) {
      alert("Failed to fetch pending orders");
    }
  };

  const handleAccept = async (orderId) => {
    if (window.confirm("Are you sure you want to move this order to Processing?")) {
      try {
        await orderProcessing(orderId);
        alert("Order moved to Processing");
        fetchPendingOrders();
      } catch (error) {
        alert("Failed to update order status");
      }
    }
  };

  const handleCancel = async (orderId) => {
    if (window.confirm("Are you sure you want to cancel this order?")) {
      try {
        await cancelOrder(orderId);
        alert("Order cancelled successfully");
        fetchPendingOrders();
      } catch (error) {
        alert("Failed to cancel order");
      }
    }
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    return new Date(dateTime).toLocaleString();
  };

  return (
    <div className="pendingorders-container">
      <div className="pending-top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/ordermanagement")}
        >
          ← Back
        </button>
        <h2>Pending Orders</h2>
      </div>

      <div className="pendingorders-list">
        {orderList.length === 0 ? (
          <p className="empty-text">No pending orders found.</p>
        ) : (
          orderList.map((order) => (
            <div className="pending-card" key={order.id}>
              <div className="pending-content">
                <h3>Order ID: {order.id}</h3>

                <p>
                  <strong>Customer:</strong>{" "}
                  {order.user?.username || order.user?.name || "N/A"}
                </p>

                <p>
                  <strong>Shipping Address:</strong>{" "}
                  {order.shippingAddress || order.address || "N/A"}
                </p>

                <p>
                  <strong>Order Time:</strong>{" "}
                  {formatDateTime(order.orderTime || order.createdAt)}
                </p>

                <p>
                  <strong>Payment:</strong>{" "}
                  {order.paymentMethod || "N/A"}
                </p>

                <p>
                  <strong>Total:</strong> ₹
                  {order.totalAmount || order.totalPrice || 0}
                </p>

                <p>
                  <strong>Status:</strong>{" "}
                  <span className="pending-status">{order.status}</span>
                </p>

                <div className="items-section">
                  <p><strong>Items:</strong></p>
                  <ul>
                    {order.orderItems && order.orderItems.length > 0 ? (
                      order.orderItems.map((item, index) => (
                        <li key={item.id || index}>
                          {item.menu?.name || item.menu?.itemName || item.itemName} — ₹
                          {item.price} x {item.quantity}
                        </li>
                      ))
                    ) : (
                      <li>No items available</li>
                    )}
                  </ul>
                </div>

                <div className="pending-btn-group">
                  <button
                    className="accept-btn"
                    onClick={() => handleAccept(order.id)}
                  >
                    Accept
                  </button>

                  <button
                    className="cancel-btn"
                    onClick={() => handleCancel(order.id)}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}