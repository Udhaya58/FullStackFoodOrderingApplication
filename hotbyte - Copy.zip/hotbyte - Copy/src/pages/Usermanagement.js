import React from "react";
import { useNavigate } from "react-router-dom";
import "../CSS/UserManagement.css";

export default function Usermanagement() {
  const navigate = useNavigate();

  return (
    <div className="usermanagement-container">

    
      <div className="usermanagement-topbar">
        <button
          className="back-btn"
          onClick={() => navigate("/admin")}
        >
          ← Back
        </button>

        <div className="usermanagement-header">
          <h1>Manage the Users</h1>
          <p>Quick actions to Add, Delete the user</p>
        </div>
      </div>

   
      <div className="usermanagement-cards">

        <div
          className="user-card"
          onClick={() => navigate("/managecustomers")}
        >
          <div className="icon-circle">
            <img
              src="https://cdn-icons-png.flaticon.com/512/1077/1077114.png"
              alt="Customers"
            />
          </div>

          <button className="user-btn">Customers</button>

          <p>Create and Delete the customer</p>
        </div>

        <div
          className="user-card"
          onClick={() => navigate("/managerestaurants")}
        >
          <div className="icon-circle">
            <img
              src="https://cdn-icons-png.flaticon.com/512/2921/2921822.png"
              alt="Restaurants"
            />
          </div>

          <button className="user-btn">Restaurants</button>

          <p>Create and Delete restaurants</p>
        </div>

      </div>
    </div>
  );
}