import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { RegisterUser } from '../services/authService';
import "../CSS/Register.css"
export default function Register() {

    const navigate=useNavigate();

    const[formData,setFormData]=useState(
        {
            name:"",
            email:"",
            password:"",
            contact:"" ,
            role:""

        }
    );
    const[errors,setErrors]=useState({});
    const[touched,setTouched]=useState({});
    const[success,setSuccess]=useState("");

    const nameregex=/^[A-Za-z\s]+$/;
    const emailregex=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordregex= /^.{6,}$/;
    const contactregex = /^[0-9]{10}$/;

    const validate=(field,value)=>{
        let error="";

        if(!value){
            error=`${field.charAt(0).toUpperCase()+field.slice(1)} is required`

        }
        else{
            if(field==="name" && !nameregex.test(value)){
                error="NAme should contains only letters"
            }
            if(field==="email" && !emailregex.test(value)){
                error="Enter a valid email"
            }
            if(field==="password" && !passwordregex.test(value)){
                error="Password must be atleast 6 characters"
            }

            if(field==="contact" && !contactregex.test(value)){
                error="Contact must conatins only 10 digits"
            }
        }
        return error;
    }

    const handleChange=(e)=>{
        const{name,value}=e.target;

        setFormData({
            ...formData,[name]:value
        });

        const error=validate(name,value);
        setErrors({
            ...errors,
            [name]:error
        })
        setSuccess("");
    }

    const handleBlur=(e)=>{
        setTouched({
            ...touched,
            [e.target.name]:true
        })
    }

    const isFormValid=
        nameregex.test(formData.name)&&
        emailregex.test(formData.email)&&
        passwordregex.test(formData.password)&&
        contactregex.test(formData.contact)&&
        formData.role!=="";


    const handleSubmit=(e)=>{
        e.preventDefault();

        if(isFormValid){
            RegisterUser(formData).then((res)=>{
                setSuccess("Registration Successfull");

                setTimeout(()=>{
                    navigate("/");
                },1500);
            }).catch((error)=>{
                    alert("Registration failed")
                })
        }
    }
  return (
    <div className="register-container">
      <div className="register-card">
        <h2 className="register-title">Create Account</h2>

        <form onSubmit={handleSubmit}>

        
          <input
            type="text"
            name="name"
            placeholder="Enter Name"
            value={formData.name}
            onChange={handleChange}
            onBlur={handleBlur}
            className="register-input"
          />
          {touched.name && errors.name && (
            <p className="error-text">{errors.name}</p>
          )}

      
          <input
            type="email"
            name="email"
            placeholder="Enter Email"
            value={formData.email}
            onChange={handleChange}
            onBlur={handleBlur}
            className="register-input"
          />
          {touched.email && errors.email && (
            <p className="error-text">{errors.email}</p>
          )}

          <input
            type="password"
            name="password"
            placeholder="Enter Password"
            value={formData.password}
            onChange={handleChange}
            onBlur={handleBlur}
            className="register-input"
          />
          {touched.password && errors.password && (
            <p className="error-text">{errors.password}</p>
          )}

          <input
            type="text"
            name="contact"
            placeholder="Enter Contact Number"
            value={formData.contact}
            onChange={handleChange}
            onBlur={handleBlur}
            className="register-input"
          />
          {touched.contact && errors.contact && (
            <p className="error-text">{errors.contact}</p>
          )}

          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
            onBlur={handleBlur}
            className="register-input"
          >
            <option value="">Select Role</option>
            <option value="USER">USER</option>
            <option value="RESTAURANT">RESTAURANT</option>
            <option value="ADMIN">ADMIN</option>
          </select>
          {touched.role && !formData.role && (
            <p className="error-text">Role is required</p>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={!isFormValid}
            className="register-btn"
          >
            REGISTER
          </button>

          {success && <p className="success-text">{success}</p>}

          <div className="login-text">
            <span>Already have an account? </span>
            <span
              className="login-link"
              style={{ cursor: "pointer" }}
              onClick={() => navigate("/")}
            >
              Login
            </span>
          </div>

        </form>
      </div>
    </div>
  );
}