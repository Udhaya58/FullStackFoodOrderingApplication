import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getOrderSummary } from "../services/userService";
import "../CSS/OrderSummaryPage.css";

export default function OrderSummaryPage() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);

  useEffect(() => {
    if (id) {
      loadOrder();
    }
  }, [id]);

  const loadOrder = async () => {
    try {

      const res = await getOrderSummary(id);

      console.log("Order Summary:", res.data);

      setOrder(res.data);

    } catch (error) {
      console.error("Error loading order", error);
    }
  };

  if (!order) return <h2 className="loading">Loading Order...</h2>;

  return (
    <div className="order-container">

      <div className="order-header-top">

        <h1>Order Summary</h1>

        <button
          className="home-btn"
          onClick={() => navigate("/user")}
        >
          🏠 Home
        </button>

      </div>

      <div className="order-header">
        <p><strong>Order ID:</strong> {order.orderId}</p>
        <p><strong>Status:</strong> {order.status}</p>
        <p><strong>Customer:</strong> {order.customerName}</p>
        <p><strong>Restaurant:</strong> {order.restaurantName}</p>
        <p><strong>Payment:</strong> {order.paymentMethod}</p>
        <p><strong>Address:</strong> {order.shippingAddress}</p>
        <p><strong>Order Time:</strong> {order.orderTime}</p>
      </div>

      <div className="order-items">

        {order.items?.map((item, index) => (

          <div className="order-item" key={index}>

            <div className="item-details">
              <h3>{item.menuName}</h3>
              <p>Quantity: {item.quantity}</p>
              <p>Price: ₹{item.price}</p>
            </div>

          </div>

        ))}

      </div>

      <div className="order-total">
        <h2>Total Paid: ₹{order.totalAmount}</h2>
      </div>

    </div>
  );
}