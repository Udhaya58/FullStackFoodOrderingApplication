import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getMenuById, updateMenu } from "../services/restaurantService";
import "../CSS/UpdateMenu.css";

export default function UpdateMenu() {
  const { id } = useParams();
  const navigate = useNavigate();

  const categories = ["STARTERS", "MAIN_COURSE", "DESSERTS", "BEVERAGES", "SNACKS", "SALADS", "SOUPS"];
  const dietaryTypes = ["VEG", "NONVEG"];
  const tasteInfos = ["SWEET", "SPICY_LIGHT", "SPICY_FULL", "MILD", "SALTY", "SOUR"];

  const [menuData, setMenuData] = useState({
    name: "",
    description: "",
    keyInged: "",
    price: "",
    availableTime: "",
    url: "",
    category: "",
    dietaryType: "",
    tasteinfo: "",
    available: true,
    nutrionalInfo: ""
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [success, setSuccess] = useState("");

  const nameRegex = /^[A-Za-z\s]+$/;
  const priceRegex = /^[0-9]+$/;

  useEffect(() => {
    fetchMenuById();
  }, []);

  const fetchMenuById = async () => {
    try {
      const res = await getMenuById(id);
      setMenuData(res.data);
    } catch (error) {
      alert("Failed to fetch menu item");
    }
  };

  const validate = (field, value) => {
    let error = "";
    if (!value && field !== "available") {
      error = `${field} is required`;
    } else {
      if (field === "name" && value && !nameRegex.test(value)) {
        error = "Only letters and spaces allowed";
      }
      if (field === "price" && value && !priceRegex.test(value)) {
        error = "Price must be numeric";
      }
      if (field === "url" && value && !/^https?:\/\/.+\.(jpg|jpeg|png|gif)$/i.test(value)) {
        error = "Enter a valid image URL";
      }
    }
    return error;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const fieldValue = type === "checkbox" ? checked : value;

    setMenuData({ ...menuData, [name]: fieldValue });
    setErrors({ ...errors, [name]: validate(name, fieldValue) });
    setSuccess("");
  };

  const handleBlur = (e) => {
    setTouched({ ...touched, [e.target.name]: true });
  };

  const isFormValid = () => {
    return (
      menuData.name &&
      nameRegex.test(menuData.name) &&
      menuData.price &&
      priceRegex.test(menuData.price) &&
      menuData.description &&
      menuData.keyInged &&
      menuData.availableTime &&
      menuData.category &&
      menuData.dietaryType &&
      menuData.tasteinfo &&
      (!menuData.url || /^https?:\/\/.+\.(jpg|jpeg|png|gif)$/i.test(menuData.url))
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid()) {
      alert("Please fix the errors before submitting");
      return;
    }

    try {
      await updateMenu(id, { ...menuData, price: Number(menuData.price) });
      setSuccess("Menu Item Updated Successfully!");
    } catch (error) {
      alert("Update failed");
    }
  };

  return (
    <div className="update-container">
      <div className="top-bar">
        <button
          className="back-btn"
          onClick={() => navigate("/editmenu")}
        >
          ← Back
        </button>
        <h2>Update Menu Item</h2>
      </div>

      <form className="update-form" onSubmit={handleSubmit}>
        <input
          name="name"
          placeholder="Item Name"
          value={menuData.name}
          onChange={handleChange}
          onBlur={handleBlur}
        />
        {touched.name && errors.name && <p className="error-text">{errors.name}</p>}

        <textarea
          name="description"
          placeholder="Description"
          value={menuData.description}
          onChange={handleChange}
          onBlur={handleBlur}
        />
        {touched.description && errors.description && <p className="error-text">{errors.description}</p>}

        <input
          type="text"
          name="keyInged"
          placeholder="Key Ingredients"
          value={menuData.keyInged}
          onChange={handleChange}
        />

        <input
          name="price"
          placeholder="Price"
          value={menuData.price}
          onChange={handleChange}
          onBlur={handleBlur}
        />
        {touched.price && errors.price && <p className="error-text">{errors.price}</p>}

        <input
          type="text"
          name="availableTime"
          placeholder="Available Time (Eg: 10AM - 10PM)"
          value={menuData.availableTime}
          onChange={handleChange}
        />

        <input
          name="url"
          placeholder="Image URL"
          value={menuData.url}
          onChange={handleChange}
        />
        {touched.url && errors.url && <p className="error-text">{errors.url}</p>}

        <select
          name="category"
          value={menuData.category}
          onChange={handleChange}
        >
          <option value="">Select Category</option>
          {categories.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
        </select>
        {touched.category && errors.category && <p className="error-text">{errors.category}</p>}

        <select
          name="dietaryType"
          value={menuData.dietaryType}
          onChange={handleChange}
        >
          <option value="">Select Dietary Type</option>
          {dietaryTypes.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        {touched.dietaryType && errors.dietaryType && <p className="error-text">{errors.dietaryType}</p>}

        <select
          name="tasteinfo"
          value={menuData.tasteinfo}
          onChange={handleChange}
        >
          <option value="">Select Taste</option>
          {tasteInfos.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        {touched.tasteinfo && errors.tasteinfo && <p className="error-text">{errors.tasteinfo}</p>}

        <textarea
          name="nutrionalInfo"
          placeholder="Nutritional Information"
          value={menuData.nutrionalInfo}
          onChange={handleChange}
        />

        <label className="checkbox-label">
          <input
            type="checkbox"
            name="available"
            checked={menuData.available}
            onChange={handleChange}
          />
          Available
        </label>

        <button
          type="submit"
          disabled={!isFormValid()}
          className="update-btn"
        >
          Update Menu
        </button>

        {success && <p className="success-text">{success}</p>}
      </form>
    </div>
  );
}