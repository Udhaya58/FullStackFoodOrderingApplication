import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getMenuById, addToCart } from "../services/userService";
import "../CSS/ProductPage.css";

export default function ProductPage() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [menu, setMenu] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const res = await getMenuById(id);
      setMenu(res.data);
    } catch (error) {
      console.error("Error fetching product", error);
    }
  };

  const increaseQty = () => {
    setQuantity(quantity + 1);
  };

  const decreaseQty = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleAddToCart = async () => {
    try {
      await addToCart(menu.id, quantity);
      alert("Item added to cart!");
      navigate("/cart");
    } catch (error) {
      console.error("Add to cart failed", error);
      alert("Failed to add item");
    }
  };

  if (!menu) {
    return <h2 className="loading">Loading...</h2>;
  }

  return (
    <div className="product-container">

      <button className="back-btn" onClick={() => navigate("/user")}>
        ← Back
      </button>

      <div className="product-card">

        <img src={menu.url} alt={menu.name} />

        <div className="product-details">

          <h1>{menu.name}</h1>

          <p className="restaurant">
            Restaurant: {menu.restaurant?.name}
          </p>

          <p className="description">
            {menu.description}
          </p>

          <p>
            <strong>Category:</strong> {menu.category}
          </p>

          <p>
            <strong>Dietary:</strong> {menu.dietaryType}
          </p>

          <p>
            <strong>Taste:</strong> {menu.tasteinfo}
          </p>

          <p>
            <strong>Ingredients:</strong> {menu.keyInged}
          </p>

          <p>
            <strong>Nutritional Info:</strong> {menu.nutrionalInfo}
          </p>

          <h2 className="price">₹{menu.price}</h2>

          {/* Quantity Selector */}
          <div className="quantity-box">
            <button onClick={decreaseQty}>-</button>
            <span>{quantity}</span>
            <button onClick={increaseQty}>+</button>
          </div>

          <button className="cart-btn" onClick={handleAddToCart}>
            Add to Cart
          </button>

        </div>

      </div>

    </div>
  );
}