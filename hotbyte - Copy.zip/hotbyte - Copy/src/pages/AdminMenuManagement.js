import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllRestaurants } from "../services/adminService";
import "../CSS/AdminMenuManagement.css";

export default function AdminMenuManagement() {
  const [restaurantList, setRestaurantList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const res = await getAllRestaurants();
      setRestaurantList(res.data);
    } catch (error) {
      alert("Failed to fetch restaurants");
    }
  };

  return (
    <div className="adminmenu-page">
      <div className="adminmenu-wrapper">
        <button
          className="back-btn"
          onClick={() => navigate("/admin")}
        >
          Back
        </button>

        <h2 className="adminmenu-title">Restaurant Menu Management</h2>

        <div className="restaurant-grid">
          {restaurantList.length === 0 ? (
            <p className="empty-text">No restaurants found.</p>
          ) : (
            restaurantList.map((restaurant) => (
              <div className="restaurant-card" key={restaurant.id}>
                <h3>{restaurant.name}</h3>

                <p>
                  <strong>Contact:</strong> {restaurant.contact}
                </p>

                <p>
                  <strong>Email:</strong> {restaurant.email}
                </p>


                <button
                  className="menu-btn"
                  onClick={() =>
                    navigate(`/adminrestaurantmenu/${restaurant.id}`, {
                      state: { restaurantName: restaurant.name }
                    })
                  }
                >
                  Menu
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}