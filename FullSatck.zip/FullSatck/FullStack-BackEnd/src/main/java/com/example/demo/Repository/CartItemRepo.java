package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.CartItem;
@Repository
public interface CartItemRepo extends JpaRepository <CartItem,Integer> {

	void deleteByMenuId(int id);

	int countByOrdersId(int id);

}
