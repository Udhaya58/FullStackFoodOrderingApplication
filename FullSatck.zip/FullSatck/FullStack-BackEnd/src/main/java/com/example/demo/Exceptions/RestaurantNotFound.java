package com.example.demo.Exceptions;

public class RestaurantNotFound extends RuntimeException {

	public RestaurantNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
