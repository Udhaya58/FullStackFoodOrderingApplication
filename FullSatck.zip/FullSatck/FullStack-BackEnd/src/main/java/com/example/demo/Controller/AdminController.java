package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Menu;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Services.AdminSer;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminSer adminSer;

   

    @PostMapping("/add-user")
    public ResponseEntity<String> addUser(@RequestBody User user) {
        return ResponseEntity.ok(adminSer.addUser(user));
    }

    @DeleteMapping("/delete-user/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable int userId) {
        return ResponseEntity.ok(adminSer.DeleteUser(userId));
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> viewAllUsers() {
        return ResponseEntity.ok(adminSer.viewAllUsers());
    }
    @GetMapping("/users/{id}")
    public ResponseEntity<User> viewuserbyid(@PathVariable int id){
    	return ResponseEntity.ok(adminSer.getuserbyid(id));
    }

    @GetMapping("/restaurant/getmenu/{resId}")
    public ResponseEntity<List<Menu>> getmenubyresid(@PathVariable int resId){
    	return ResponseEntity.ok(adminSer.getallmenubyresid(resId));
    }

    @PostMapping("/add-restaurant")
    public ResponseEntity<String> addRestaurant(@RequestBody Restaurant restaurant) {
        return ResponseEntity.ok(adminSer.addRestaurant(restaurant));
    }

    @DeleteMapping("/delete-restaurant/{resId}")
    public ResponseEntity<String> deleteRestaurant(@PathVariable int resId) {
        return ResponseEntity.ok(adminSer.deleteRestaurant(resId));
    }

    @GetMapping("/restaurants")
    public ResponseEntity<List<Restaurant>> viewAllRestaurants() {
        return ResponseEntity.ok(adminSer.viewAllRestaurants());
    }

    

    @PostMapping("/add-menu/{resId}")
    public ResponseEntity<Menu> addMenu(@PathVariable int resId, @RequestBody Menu menu) {
        return ResponseEntity.ok(adminSer.AddMenu(resId, menu));
    }
    
    @GetMapping("/menu/{menuId}")
    public ResponseEntity<Menu> getmenubyid(@PathVariable int menuId){
    	return ResponseEntity.ok(adminSer.getallmenubyid(menuId));
    }

    @PutMapping("/update-menu/{menuId}")
    public ResponseEntity<Menu> updateMenu(
            @PathVariable int menuId,
            @RequestBody Menu updatedMenu) {
        return ResponseEntity.ok(adminSer.UpdateMenu(menuId, updatedMenu));
    }

    @DeleteMapping("/delete-menu/{menuId}")
    public ResponseEntity<String> deleteMenu(
        
            @PathVariable int menuId) {
        return ResponseEntity.ok(adminSer.DeleteById( menuId));
    }
}

