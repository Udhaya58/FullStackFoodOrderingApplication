package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class OrderItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	 @ManyToOne
	 private Menu menu;

	 private int quantity;
	 private Double price;

	 @ManyToOne
	 @JsonBackReference
	 private Orders orders;


	 public OrderItem(Menu menu, int quantity, Double price, Orders orders) {
		super();
		this.menu = menu;
		this.quantity = quantity;
		this.price = price;
		this.orders = orders;
	 }
	 
	 

}
