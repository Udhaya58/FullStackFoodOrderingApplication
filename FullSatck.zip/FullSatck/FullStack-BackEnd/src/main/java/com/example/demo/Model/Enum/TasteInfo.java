package com.example.demo.Model.Enum;

public enum TasteInfo {
	SWEET, SPICY_LIGHT, SPICY_FULL, MILD, SALTY, SOUR;

}
