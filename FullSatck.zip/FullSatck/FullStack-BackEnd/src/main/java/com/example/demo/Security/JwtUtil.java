package com.example.demo.Security;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Exceptions.EmailIdNotFound;
import com.example.demo.Model.Admin;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Repository.AdminRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Repository.UserRepo;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.security.Key;

@Component
public class JwtUtil {
	@Autowired
	private UserRepo userrepo;
	
	@Autowired
	private RestaurantRepo resrepo;
	@Autowired
	private AdminRepo adminrepo;
	
	//secret key
	private static SecretKey secretkey=Keys.secretKeyFor(SignatureAlgorithm.HS512);
	
	//expire time
	private final int jwtExpirationtimeMs=86400000;
	
	//Generate Token
	public String generateToken(String username) {
		
		
		//Adding roles and id to the token
		Optional<User> useropt=userrepo.findByEmail(username);
		if(useropt.isPresent()) {
			User user = useropt.get();
			return Jwts.builder().setSubject(username).claim("role",user.getRole()).claim("id", user.getId())
					.setIssuedAt(new Date()).setExpiration(new Date(new Date().getTime()+jwtExpirationtimeMs))
					.signWith(secretkey).compact();
		}
		Optional<Restaurant> restaurantopt =resrepo.findByEmail(username);
		if(restaurantopt.isPresent()) {
			Restaurant res=restaurantopt.get();
			return Jwts.builder().setSubject(username).claim("role",res.getRole()).claim("id",res.getId()).setIssuedAt(new Date())
					.setExpiration(new Date(new Date().getTime()+jwtExpirationtimeMs))
					.signWith(secretkey).compact();
					
		}
		Optional<Admin> adminopt=adminrepo.findByEmail(username);
		if(adminopt.isPresent()) {
			Admin admin=adminopt.get();
			return Jwts.builder().setSubject(username).claim("role",admin.getRole()).claim("id",admin.getId()).setIssuedAt(new Date())
					.setExpiration(new Date(new Date().getTime()+jwtExpirationtimeMs)).signWith(secretkey).compact();
		}
		throw new EmailIdNotFound("Email id is not found");
		
	}
	
	
	
	//Extracting username(email)
	public String extractUsername(String token) {
        return Jwts.parser()
                .setSigningKey(secretkey)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
	//Extracting roles
	public String extractRoles (String token){
		return Jwts.parser().setSigningKey(secretkey).build()
				.parseClaimsJws(token).getBody().get("role",String.class);
		
	}
	//Extracting id
	public int extractId(String token){
		return Jwts.parser().setSigningKey(secretkey).build().parseClaimsJws(token)
				.getBody().get("id",Integer.class);
		
	}
	//Token Validation
	public boolean isTokenValid(String token) {
		try {
			Jwts.parser().setSigningKey(secretkey).build().parseClaimsJws(token);
			return true;
		}
		catch(JwtException | IllegalArgumentException e) {
			return false;
		}
	}

}
