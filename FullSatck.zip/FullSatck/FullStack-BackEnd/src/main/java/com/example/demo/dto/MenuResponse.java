package com.example.demo.dto;

import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.Model.Enum.TasteInfo;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MenuResponse {
	private int id;
	private String name;
	private String description;
	private String keyInged;
	private Double price;
	private String availableTime;
	private String url;
	
	@Enumerated(EnumType.STRING)
	private Category category;
	
	@Enumerated(EnumType.STRING)
	private DietaryType dietaryType;
	
	
	@Enumerated(EnumType.STRING)
	private TasteInfo tasteinfo;
	
	private Boolean available=true;
	private String  nutrionalInfo;

}
