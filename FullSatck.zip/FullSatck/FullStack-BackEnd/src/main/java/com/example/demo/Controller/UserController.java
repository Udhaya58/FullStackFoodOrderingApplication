package com.example.demo.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Cart;
import com.example.demo.Model.CartItem;
import com.example.demo.Model.Menu;
import com.example.demo.Model.Orders;
import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.Services.UserServ;
import com.example.demo.dto.OrderSummaryDTO;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/user")
@CrossOrigin("*")
public class UserController {

    @Autowired
    private UserServ userServ;

  

    @GetMapping("/menus")
    public ResponseEntity<List<Menu>> getAllMenus() {
        return ResponseEntity.ok(userServ.getallmenu());
    }

    @GetMapping("/menus/restaurant/{resId}")
    public ResponseEntity<List<Menu>> getByRestaurant(@PathVariable int resId) {
        return ResponseEntity.ok(userServ.getbyrestaurantid(resId));
    }

    @GetMapping("/menus/search")
    public ResponseEntity<List<Menu>> searchByKeyword(@RequestParam String keyword) {
        return ResponseEntity.ok(userServ.searchMenuByKeyword(keyword));
    }

    @GetMapping("/menus/name")
    public ResponseEntity<List<Menu>> getByName(@RequestParam String name) {
        return ResponseEntity.ok(userServ.getMenuByName(name));
    }

    @GetMapping("/menus/category")
    public ResponseEntity<List<Menu>> getByCategory(@RequestParam Category category) {
        return ResponseEntity.ok(userServ.getMenuByCategory(category));
    }

    @GetMapping("/menus/price-range")
    public ResponseEntity<List<Menu>> getByPriceRange(@RequestParam double min, @RequestParam double max) {
        return ResponseEntity.ok(userServ.getByPriceRange(min, max));
    }

    @GetMapping("/menus/filter")
    public ResponseEntity<List<Menu>> getFilteredMenus(
        @RequestParam(required = false) String category,
        @RequestParam(required = false) String dietary,
        @RequestParam(required = false) Double minPrice,
        @RequestParam(required = false) Double maxPrice) {

        Category categoryEnum = null;
        DietaryType dietaryEnum = null;

        try {
            if (category != null && !category.isEmpty()) {
                categoryEnum = Category.valueOf(category.toUpperCase());
            }
            if (dietary != null && !dietary.isEmpty()) {
                dietaryEnum = DietaryType.valueOf(dietary.toUpperCase());
            }
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null); 
        }

        List<Menu> filtered = userServ.getMenusWithFilters(categoryEnum, dietaryEnum, minPrice, maxPrice);
        return ResponseEntity.ok(filtered);
    }
    @GetMapping("/menu/getid/{id}")
    public ResponseEntity<Menu> getbymenuid(@PathVariable int id){
    	return ResponseEntity.ok(userServ.getmenubyid(id)) ;
    	}



 

    @PostMapping("/cart/add")
    public ResponseEntity<CartItem> addToCart(
            HttpServletRequest request,
            @RequestParam int menuId,
            @RequestParam int quantity) {
        return ResponseEntity.ok(userServ.addToCart(request, menuId, quantity));
    }

    @GetMapping("/cart")
    public ResponseEntity<Cart> getCart(HttpServletRequest request) {
        return ResponseEntity.ok(userServ.getCartbyUserId(request));
    }

    @PutMapping("/cart/item/{itemId}")
    public ResponseEntity<CartItem> updateCartItem(
            @PathVariable int itemId,
            @RequestParam int quantity) {
        return ResponseEntity.ok(userServ.updateCartItemQuantity(itemId, quantity));
    }

    @DeleteMapping("/cart/item/{itemId}")
    public ResponseEntity<String> removeCartItem(@PathVariable int itemId) {
        userServ.removeItem(itemId);
        return ResponseEntity.ok("Item removed from cart successfully");
    }
    @PutMapping("/cart/item/{itemId}/quantity")
    public ResponseEntity<Cart> updateCartItemQuantity(
            @PathVariable int itemId,
            @RequestParam int quantity) {
        Cart updatedCart = userServ.updateQuantity(itemId, quantity);
        return ResponseEntity.ok(updatedCart);
    }

 

    @PostMapping("/checkout")
    public ResponseEntity<Orders> checkout(HttpServletRequest request, @RequestBody Orders order) {
        return ResponseEntity.ok(userServ.checkout(request, order));
    }

    @GetMapping("/orders")
    public ResponseEntity<List<Orders>> viewAllOrders(HttpServletRequest request) {
        return ResponseEntity.ok(userServ.viewAllOrder(request));
    }
    @GetMapping("/order/summary/{orderId}")
    public ResponseEntity<OrderSummaryDTO> getOrderSummary(@PathVariable int orderId) {
        OrderSummaryDTO summary = userServ.viewOrderSummary(orderId);
        return ResponseEntity.ok(summary);
    }

}
