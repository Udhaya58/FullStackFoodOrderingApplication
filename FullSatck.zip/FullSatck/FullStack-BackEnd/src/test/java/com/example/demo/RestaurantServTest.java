package com.example.demo;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.RestaurantNotFound;
import com.example.demo.Model.*;
import com.example.demo.Repository.*;
import com.example.demo.Security.JwtUtil;
import com.example.demo.Services.RestaurantServ;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class RestaurantServTest {

    @InjectMocks
    private RestaurantServ restaurantServ;

    @Mock
    private RestaurantRepo resRepo;

    @Mock
    private MenuRepo menuRepo;

    @Mock
    private OrdersRepo ordersRepo;

    @Mock
    private CartItemRepo orderitemrepo;

    @Mock
    private JwtUtil jwtutil;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private HttpServletRequest request;

    private final int mockRestaurantId = 101;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        when(request.getHeader("Authorization")).thenReturn("Bearer testtoken");
        when(jwtutil.extractId("testtoken")).thenReturn(mockRestaurantId);
    }

   

    @Test
    void testAddMenu() {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(mockRestaurantId);

        Menu newMenu = new Menu();
        newMenu.setName("Pasta");

        when(resRepo.findById(mockRestaurantId)).thenReturn(Optional.of(restaurant));
        when(menuRepo.save(any(Menu.class))).thenAnswer(i -> i.getArguments()[0]);

        Menu result = restaurantServ.AddMenu(request, newMenu);

        assertEquals("Pasta", result.getName());
        assertEquals(restaurant, result.getRestaurant());
    }

    @Test
    void testDeleteById_MenuNotFoundInRestaurant() {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(mockRestaurantId);

        Menu menu = new Menu();
        menu.setId(5);
        menu.setRestaurant(new Restaurant());
        menu.getRestaurant().setId(999); // different restaurant

        when(resRepo.findById(mockRestaurantId)).thenReturn(Optional.of(restaurant));
        when(menuRepo.findById(5)).thenReturn(Optional.of(menu));

        Exception exception = assertThrows(MenuNotFound.class, () ->
                restaurantServ.DeleteById(request, 5));

        assertTrue(exception.getMessage().contains("does not belong"));
    }

    @Test
    void testDeleteById_SuccessfulDeletion() {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(mockRestaurantId);

        Menu menu = new Menu();
        menu.setId(5);
        menu.setRestaurant(restaurant);

        Orders order1 = new Orders();
        order1.setId(1);
        order1.setRestaurant(restaurant);

        when(resRepo.findById(mockRestaurantId)).thenReturn(Optional.of(restaurant));
        when(menuRepo.findById(5)).thenReturn(Optional.of(menu));
        when(ordersRepo.findAllByRestaurantId(mockRestaurantId)).thenReturn(List.of(order1));
        when(orderitemrepo.countByOrdersId(1)).thenReturn(0);

        String result = restaurantServ.DeleteById(request, 5);
        assertEquals("Menu and all related items deleted successfully.", result);

        verify(menuRepo).delete(menu);
        verify(ordersRepo).delete(order1);
    }
}
