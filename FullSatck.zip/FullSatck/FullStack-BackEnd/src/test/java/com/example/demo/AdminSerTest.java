package com.example.demo;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.RestaurantNotFound;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Model.*;
import com.example.demo.Repository.*;
import com.example.demo.Security.JwtUtil;
import com.example.demo.Services.AdminSer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdminSerTest {

    @InjectMocks
    private AdminSer adminSer;

    @Mock
    private UserRepo userRepo;

    @Mock
    private RestaurantRepo restaurantRepo;

    @Mock
    private MenuRepo menuRepo;

    @Mock
    private OrdersRepo ordersRepo;

    @Mock
    private CartRepo cartRepo;

    @Mock
    private CartItemRepo cartItemRepo;

    @Mock
    private OrderItemRepo orderItemRepo;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddUser() {
        User user = new User();
        user.setName("Test");
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(passwordEncoder.encode("password")).thenReturn("encodedPass");

        String result = adminSer.addUser(user);
        assertEquals("User registered successfully", result);
        verify(userRepo).save(any(User.class));
    }

    @Test
    void testAddRestaurant() {
        Restaurant res = new Restaurant();
        res.setName("TestRes");
        res.setEmail("res@example.com");
        res.setPassword("respass");
  

        when(passwordEncoder.encode("respass")).thenReturn("encodedPass");

        String result = adminSer.addRestaurant(res);
        assertEquals("Restaurant registered successfully", result);
        verify(restaurantRepo).save(any(Restaurant.class));
    }

    @Test
    void testGetUserById_UserExists() {
        User user = new User();
        user.setId(1);
        when(userRepo.findById(1)).thenReturn(Optional.of(user));

        User found = adminSer.getuserbyid(1);
        assertEquals(1, found.getId());
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> adminSer.getuserbyid(1));
    }

    @Test
    void testAddMenu() {
        Restaurant res = new Restaurant();
        res.setId(5);
        Menu menu = new Menu();
        menu.setName("Burger");

        when(restaurantRepo.findById(5)).thenReturn(Optional.of(res));
        when(menuRepo.save(any(Menu.class))).thenAnswer(i -> i.getArguments()[0]);

        Menu savedMenu = adminSer.AddMenu(5, menu);
        assertEquals("Burger", savedMenu.getName());
        assertEquals(res, savedMenu.getRestaurant());
    }

    @Test
    void testUpdateMenu_MenuExists() {
        Menu menu = new Menu();
        menu.setId(2);
        menu.setName("Old");

        Menu updated = new Menu();
        updated.setName("New");

        when(menuRepo.findById(2)).thenReturn(Optional.of(menu));
        when(menuRepo.save(any())).thenAnswer(i -> i.getArguments()[0]);

        Menu result = adminSer.UpdateMenu(2, updated);
        assertEquals("New", result.getName());
    }

    @Test
    void testDeleteUser_Success() {
        User user = new User();
        user.setId(3);

        Orders order = new Orders();
        order.setId(10);

        when(userRepo.findById(3)).thenReturn(Optional.of(user));
        when(ordersRepo.findByUserId(3)).thenReturn(List.of(order));

        String result = adminSer.DeleteUser(3);
        assertEquals("User deleted successfully", result);
        verify(orderItemRepo).deleteByOrdersId(10);
        verify(ordersRepo).deleteAll(anyList());
        verify(userRepo).delete(user);
    }

    @Test
    void testDeleteRestaurant_Success() {
        Restaurant res = new Restaurant();
        res.setId(100);
        Menu menu = new Menu(); menu.setId(1); menu.setRestaurant(res);
        Orders order = new Orders(); order.setId(5); order.setRestaurant(res);

        when(restaurantRepo.findById(100)).thenReturn(Optional.of(res));
        when(ordersRepo.findAllByRestaurantId(100)).thenReturn(List.of(order));
        when(menuRepo.findAllByRestaurantId(100)).thenReturn(List.of(menu));

        String result = adminSer.deleteRestaurant(100);
        assertEquals("Restaurant and all related records deleted.", result);
        verify(orderItemRepo).deleteByOrdersId(5);
        verify(orderItemRepo).deleteByMenuId(1);
        verify(ordersRepo).deleteAll(List.of(order));
        verify(menuRepo).deleteAll(List.of(menu));
        verify(restaurantRepo).delete(res);
    }

    @Test
    void testGetMenuById_MenuExists() {
        Menu menu = new Menu();
        menu.setId(10);
        when(menuRepo.findById(10)).thenReturn(Optional.of(menu));
        Menu result = adminSer.getallmenubyid(10);
        assertEquals(10, result.getId());
    }

    @Test
    void testGetMenuById_NotFound() {
        when(menuRepo.findById(99)).thenReturn(Optional.empty());
        assertThrows(MenuNotFound.class, () -> adminSer.getallmenubyid(99));
    }
}
