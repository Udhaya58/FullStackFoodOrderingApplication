package com.example.demo;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Model.*;
import com.example.demo.Repository.*;
import com.example.demo.Security.JwtUtil;
import com.example.demo.Services.UserServ;

import jakarta.servlet.http.HttpServletRequest;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserServTest {

    @InjectMocks
    private UserServ userServ;

    @Mock
    private UserRepo userrepo;

    @Mock
    private MenuRepo menurepo;

    @Mock
    private OrdersRepo ordersrepo;

    @Mock
    private CartRepo cartrepo;

    @Mock
    private JwtUtil jwtutil;

    @Mock
    private RestaurantRepo resrepo;

    @Mock
    private CartItemRepo cartitemrepo;

    @Mock
    private HttpServletRequest request;

    private final int mockUserId = 1;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        when(request.getHeader("Authorization")).thenReturn("Bearer mocktoken");
        when(jwtutil.extractId("mocktoken")).thenReturn(mockUserId);
    }

    
    @Test
    public void testGetAllMenu() {
        List<Menu> mockMenus = List.of(new Menu(), new Menu());
        when(menurepo.findAll()).thenReturn(mockMenus);

        List<Menu> result = userServ.getallmenu();
        assertEquals(2, result.size());
    }

    
    @Test
    public void testAddToCart() {
        User user = new User();
        user.setId(mockUserId);

        Menu menu = new Menu();
        menu.setId(10);
        menu.setPrice(100.0);

        Cart cart = new Cart();
        cart.setUser(user);
        cart.setCartitem(new ArrayList<>());

        when(userrepo.findById(mockUserId)).thenReturn(Optional.of(user));
        when(menurepo.findById(10)).thenReturn(Optional.of(menu));
        when(cartrepo.findByUserId(mockUserId)).thenReturn(Optional.of(cart));
        when(cartitemrepo.save(any())).thenAnswer(i -> i.getArguments()[0]);

        CartItem item = userServ.addToCart(request, 10, 2);

        assertEquals(200, item.getPrice());
        assertEquals(2, item.getQuantity());
    }

   
    @Test
    public void testGetCartByUserId() {
        Cart cart = new Cart();
        when(cartrepo.findByUserId(mockUserId)).thenReturn(Optional.of(cart));

        Cart result = userServ.getCartbyUserId(request);
        assertNotNull(result);
    }

  
    @Test
    public void testUpdateCartItemQuantity() {
        Menu menu = new Menu();
        menu.setPrice(50.0);
        CartItem item = new CartItem();
        item.setMenu(menu);
        when(cartitemrepo.findById(1)).thenReturn(Optional.of(item));
        when(cartitemrepo.save(any())).thenAnswer(i -> i.getArguments()[0]);
        CartItem updated = userServ.updateCartItemQuantity(1, 3);
        assertEquals(3, updated.getQuantity());
        assertEquals(150, updated.getPrice());
    }

   
    @Test
    public void testGetMenuById_MenuNotFound() {
        when(menurepo.findById(99)).thenReturn(Optional.empty());
        assertThrows(MenuNotFound.class, () -> userServ.getmenubyid(99));
    }
    
    @Test
    public void testAddToCart_InvalidUser() {
        when(userrepo.findById(mockUserId)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> userServ.addToCart(request, 1, 1));
    }
}
