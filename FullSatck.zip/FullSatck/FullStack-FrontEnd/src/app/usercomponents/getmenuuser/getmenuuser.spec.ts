import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Getmenuuser } from './getmenuuser';

describe('Getmenuuser', () => {
  let component: Getmenuuser;
  let fixture: ComponentFixture<Getmenuuser>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Getmenuuser]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Getmenuuser);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
