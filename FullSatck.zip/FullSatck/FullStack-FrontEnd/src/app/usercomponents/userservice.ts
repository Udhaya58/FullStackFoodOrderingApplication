import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
const baseUrl='http://localhost:9988/api/user';
@Injectable({
  providedIn: 'root'
})
export class Userservice {

  constructor(private http:HttpClient,private router:Router) { }
  getallmenu(){
    return this.http.get(`${baseUrl}/menus`);
  }
 getmenubyname(menuname: string) {
  return this.http.get(`${baseUrl}/menus/search`, {
    params: { keyword: menuname }
  });
}
getfiltermenu(category:any,dietary:any,minPrice:any,maxPrice:any){
  return this.http.get(`${baseUrl}/menus/filter`,{
    params:{
      category:category,
      dietary:dietary,
      minPrice:minPrice,
      maxPrice:maxPrice
    }
  })
}
getmenubyid(meuid:number):Observable<any>{
  return this.http.get(`${baseUrl}/menu/getid/${meuid}`);
}



addToCart(menuId: number, quantity: number) {
  const params = new HttpParams()
    .set('menuId', menuId)
    .set('quantity', quantity);

  return this.http.post(`${baseUrl}/cart/add`, null, { params });
}

viewcart(){
  return this.http.get(`${baseUrl}/cart`);
}
removecart(itemid:number){
  return this.http.delete(`${baseUrl}/cart/item/${itemid}`,{
    responseType:'text'
  });
}


updateQuantity(itemId: number, newQuantity: number): Observable<any> {
  return this.http.put(`${baseUrl}/cart/item/${itemId}/quantity`, null, {
    params: { quantity: newQuantity },
    responseType: 'json'
  });
}
placeorder(orderData:any){
  return this.http.post(`${baseUrl}/checkout`,orderData)
}
ordersummary(id:number){
  return this.http.get(`${baseUrl}/order/summary/${id}`);
}
vieworder(){
  return this.http.get(`${baseUrl}/orders`);
}


}
