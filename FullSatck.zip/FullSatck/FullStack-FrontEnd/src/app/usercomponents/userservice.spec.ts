import { TestBed } from '@angular/core/testing';

import { Userservice } from './userservice';

describe('Userservice', () => {
  let service: Userservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Userservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
