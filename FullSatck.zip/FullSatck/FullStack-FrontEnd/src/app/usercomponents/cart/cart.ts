import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.html',
  styleUrl: './cart.css'
})
export class Cart implements OnInit {
  cart: any = {
    id: 0,
    user: {},
    cartitem: [],
    totalprice: 0
  };

  constructor(private userservice: Userservice,private router:Router) {}

  ngOnInit() {
    this.viewcart();
  }

  viewcart() {
    this.userservice.viewcart().subscribe({
      next: (res) => {
        console.log(res);
        this.cart = res;
      },
      error: (err) => {
        console.error('Error loading cart:', err);
      }
    });
  }

  removecart(itemid:number){
    return this.userservice.removecart(itemid).subscribe({
      next:res=>{
        console.log(res);
        this.viewcart();
      
      }
    })

  }
  updateQuantity(id:number,quantity:number){
    return this.userservice.updateQuantity(id,quantity).subscribe({
      next:res=>{
        console.log(res);
        this.cart=res;
      }
    })
    
  }
    logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('USER');


  this.router.navigate(['/login']);
}
}


