import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

const baseUrl='http://localhost:9988/auth';
@Injectable({
  providedIn: 'root'
})
export class Registerservice {

  constructor(private http:HttpClient,private router:Router) {
   }
   registerUser(user:any){
   return this.http.post(`${baseUrl}/register`, user);

   }
   loginUser(user:any){
    return this.http.post(`${baseUrl}/login`, user);

   }
   



}
