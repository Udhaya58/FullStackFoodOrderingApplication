import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data['expectedRole'];
    const token = localStorage.getItem('jwtToken');

    if (!token) {
      this.router.navigate(['/login']);
      return false;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));

      if (payload.role !== expectedRole) {
        alert("Unauthorized");
        this.router.navigate(['/login']);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Invalid token:', error);
      this.router.navigate(['/login']);
      return false;
    }
  }
}
