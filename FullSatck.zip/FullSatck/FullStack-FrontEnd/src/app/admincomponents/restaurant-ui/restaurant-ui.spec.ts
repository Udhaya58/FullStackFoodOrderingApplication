import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantUi } from './restaurant-ui';

describe('RestaurantUi', () => {
  let component: RestaurantUi;
  let fixture: ComponentFixture<RestaurantUi>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RestaurantUi]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RestaurantUi);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
