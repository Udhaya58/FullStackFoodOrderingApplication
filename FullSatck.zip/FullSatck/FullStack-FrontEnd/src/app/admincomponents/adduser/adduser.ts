import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-adduser',
  standalone: false,
  templateUrl: './adduser.html',
  styleUrl: './adduser.css'
})
export class Adduser implements OnInit {
  user!:FormGroup;
  constructor(private adminserv:Adminservice,private fb:FormBuilder){

  }
  ngOnInit(): void {
    this.user=this.fb.group({
      name:[null,[Validators.required]],
      age:[null,[Validators.required]],
      contact:[null,[Validators.required]],
      email:[null,[Validators.email]],
      password:[null,[Validators.minLength(6)]]

    })
      
  }

  adduser(){
    return this.adminserv.adduser1(this.user.value).subscribe({
      next:res=>{
        console.log(res);
        alert('user added successfully')

      }
    })
  }


}
