import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Adminservice } from '../adminservice';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-adminupdatemenu',
  standalone: false,
  templateUrl: './adminupdatemenu.html',
  styleUrl: './adminupdatemenu.css'
})
export class Adminupdatemenu implements OnInit {
 upDatemenuForm!:FormGroup
 id!:any;
  successful:any;
  constructor(private adminser:Adminservice,private fb:FormBuilder,private activeRoute:ActivatedRoute){

  }
  ngOnInit(): void {
    this.id=this.activeRoute.snapshot.paramMap.get('id');
  this.getmenubyid();
     this.upDatemenuForm=this.fb.group({
     name:[null,[Validators.required]],
     description:[null,[Validators.required]],
     keyInged:[null,[Validators.required]],
      price:[null,[Validators.required]],
      availableTime:[null,[Validators.required]],
      url:[null,[Validators.required]],
      category:[null,[Validators.required]],
      dietaryType:[null,[Validators.required]],
      tasteinfo:[null,[Validators.required]],
      nutrionalInfo:[null,[Validators.required]]
    })
      
  }
  getmenubyid(){
    return this.adminser.getmenubyid(this.id).subscribe({
      next:res=>{
        console.log(res);
        this.upDatemenuForm.patchValue(res);
      }
    })
  }
  updateMenu(){
    return this.adminser.updatemenubyid(this.id,this.upDatemenuForm.value).subscribe({
      next:res=>{
        console.log(res);
        this.upDatemenuForm=res;
      }
    })
  }
  


}







