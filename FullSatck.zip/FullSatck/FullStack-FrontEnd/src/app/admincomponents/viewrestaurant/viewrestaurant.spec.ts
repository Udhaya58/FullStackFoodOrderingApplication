import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Viewrestaurant } from './viewrestaurant';

describe('Viewrestaurant', () => {
  let component: Viewrestaurant;
  let fixture: ComponentFixture<Viewrestaurant>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Viewrestaurant]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Viewrestaurant);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
