import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usermanagement',
  standalone: false,
  templateUrl: './usermanagement.html',
  styleUrl: './usermanagement.css'
})
export class Usermanagement {
  constructor(private router:Router){

  }
  logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('ADMIN');


  this.router.navigate(['/login']);
}

}
