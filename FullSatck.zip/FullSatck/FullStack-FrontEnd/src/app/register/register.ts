import { Component } from '@angular/core';
import { Registerservice } from '../registerservice';
import { FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  constructor(private registerService: Registerservice, private fb: FormBuilder) {}

  registerForm!: any;
  successfull!:any;

  ngOnInit() {
    this.registerForm = this.fb.group(
      {
        name: [null, [Validators.required]],
        contact:['',[Validators.required]],
        email: [null, [Validators.required, Validators.email]],
        password: [null, [Validators.required, Validators.minLength(6)]],
        confirmPassword: [null, [Validators.required]],
        role: [null, [Validators.required]],
      },
      { validators: this.passwordMatchValidator }
    );
  }


  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password')?.value;
    const confirmPassword = control.get('confirmPassword')?.value;
    if (password && confirmPassword && password !== confirmPassword) {
      return { passwordMismatch: true };
    }
    return null;
  }

  registerUSer() {
    if (this.registerForm.valid) {
      const { name,contact, email, password, role } = this.registerForm.value;
      const userData = {
        name,
        contact,
        email,
        password,
        role: role.toUpperCase()
      };

      this.registerService.registerUser(userData).subscribe(res => {
        console.log(res);
        console.log(userData);
        this.successfull='Registeration Successfull';
      });
    } else {
      this.registerForm.markAllAsTouched(); 
    }
  }
}
