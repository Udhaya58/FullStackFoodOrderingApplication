import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ordermanagement } from './ordermanagement';

describe('Ordermanagement', () => {
  let component: Ordermanagement;
  let fixture: ComponentFixture<Ordermanagement>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Ordermanagement]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ordermanagement);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
