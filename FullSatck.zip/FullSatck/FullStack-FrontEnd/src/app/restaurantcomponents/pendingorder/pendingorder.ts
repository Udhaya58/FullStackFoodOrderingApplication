import { Component, OnInit } from '@angular/core';
import { Restaurantdashboard } from '../../restaurantdashboard/restaurantdashboard';
import { Restaurantservice } from '../../restaurantservice';

@Component({
  selector: 'app-pendingorder',
  standalone: false,
  templateUrl: './pendingorder.html',
  styleUrl: './pendingorder.css'
})
export class Pendingorder implements OnInit{
  pending:any;
  constructor(private resservice:Restaurantservice){

  }
  ngOnInit(){
    this.viewpendingorders();

  }
  viewpendingorders(){
    return this.resservice.viewpendingorder().subscribe({
      next:res=>{
        console.log(res);
        this.pending=res;
      }
    })
  }

  pendorders(id:number){
      return this.resservice.acceptorders(id).subscribe({
        next:res=>{
          console.log(res);
          this.viewpendingorders();
        }
      })


  }
  cancelorder(id:number){
    return this.resservice.setcancelled(id).subscribe({
      next:res=>{
        console.log(res);
        this.viewpendingorders();
      }
    })
  }

}
