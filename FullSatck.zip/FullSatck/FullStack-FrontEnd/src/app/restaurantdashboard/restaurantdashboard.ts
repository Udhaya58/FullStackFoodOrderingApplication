import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-restaurantdashboard',
  standalone: false,
  templateUrl: './restaurantdashboard.html',
  styleUrl: './restaurantdashboard.css'
})
export class Restaurantdashboard {
  constructor(private router:Router) {
    
  }
  logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('RESTAURANT');


  this.router.navigate(['/login']);
}
}
