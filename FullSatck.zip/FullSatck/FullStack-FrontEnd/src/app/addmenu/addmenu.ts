import { Component } from '@angular/core';
import { Restaurantservice } from '../restaurantservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-addmenu',
  standalone: false,
  templateUrl: './addmenu.html',
  styleUrl: './addmenu.css'
})
export class Addmenu {
  successful : any;
  menuForm!:FormGroup;
  constructor(private resservicse: Restaurantservice,private fb:FormBuilder){

  }
  ngOnInit(){
    this.menuForm=this.fb.group({
      name:['',[Validators.required]],
      description:['',[Validators.required]],
      keyInged:['',[Validators.required]],
      price:['',[Validators.required]],
      availableTime:['',[Validators.required]],
      url:['',[Validators.required]],
      category:['',[Validators.required]],
      dietaryType:['',[Validators.required]],
      tasteinfo:['',[Validators.required]],
      nutrionalInfo:['',[Validators.required]]
    })


  }

  postMenu(){
    this.resservicse.postMenu(this.menuForm.value).subscribe(res=>{
      console.log(res);
      alert("Menu Added Successfully");
      this.successful = "Menu Added Successfully";
      this.menuForm.reset();
    })
  }







}
