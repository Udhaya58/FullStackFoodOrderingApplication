import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Outstock } from './outstock';

describe('Outstock', () => {
  let component: Outstock;
  let fixture: ComponentFixture<Outstock>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Outstock]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Outstock);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
