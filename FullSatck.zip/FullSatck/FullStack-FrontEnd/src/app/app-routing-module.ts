import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Register } from './register/register';
import { Login } from './login/login';
import { Admindashboard } from './admindashboard/admindashboard';
import { Restaurantdashboard } from './restaurantdashboard/restaurantdashboard';
import { RoleGuard } from './role-guard';
import { authguardGuard } from './authguard-guard';
import { MenuManagement } from './menu-management/menu-management';
import { Addmenu } from './addmenu/addmenu';
import { Getallmenu } from './getallmenu/getallmenu';
import { Updatemenu } from './updatemenu/updatemenu';
import { Instock } from './instock/instock';
import { Outstock } from './outstock/outstock';
import { Userdashboard } from './usercomponents/userdashboard/userdashboard';
import { Setprofile } from './setprofile/setprofile';
import { Getmenuuser } from './usercomponents/getmenuuser/getmenuuser';
import { Cart } from './usercomponents/cart/cart';
import { Checkout } from './usercomponents/checkout/checkout';
import { Summaryorder } from './usercomponents/summaryorder/summaryorder';
import { Orderview } from './usercomponents/orderview/orderview';
import { Ordermanagement } from './restaurantcomponents/ordermanagement/ordermanagement';
import { Pendingorder } from './restaurantcomponents/pendingorder/pendingorder';
import { Processingorder } from './restaurantcomponents/processingorder/processingorder';
import { Outfordelivery } from './restaurantcomponents/outfordelivery/outfordelivery';
import { Orderhistory } from './restaurantcomponents/orderhistory/orderhistory';
import { Navorder } from './restaurantcomponents/navorder/navorder';
import { Usermanagement } from './admincomponents/usermanagement/usermanagement';
import { UserUi } from './admincomponents/user-ui/user-ui';
import { Adduser } from './admincomponents/adduser/adduser';
import { Deleteuser } from './admincomponents/deleteuser/deleteuser';
import { RestaurantUi } from './admincomponents/restaurant-ui/restaurant-ui';
import { Addrestaurant } from './admincomponents/addrestaurant/addrestaurant';
import { Deleterestaurant } from './admincomponents/deleterestaurant/deleterestaurant';
import { Adminmenu } from './admincomponents/adminmenu/adminmenu';
import { Viewrestaurant } from './admincomponents/viewrestaurant/viewrestaurant';
import { Adminviewmenu } from './admincomponents/adminviewmenu/adminviewmenu';
import { Adminupdatemenu } from './admincomponents/adminupdatemenu/adminupdatemenu';




const routes: Routes = [
  {
    path:'registerpage',
    component:Register
  },
  {
    path:"",
    component:Login
  },
  {
    path:'login',
    component:Login
  },
  {
    path:"admindashboard",
    component:Admindashboard,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'ADMIN' }
  },

  {
    path:"restaurantdashboard",
    component:Restaurantdashboard,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'RESTAURANT' }
  },

  {
    path:"menumanagement",
    component:MenuManagement,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'RESTAURANT'}
  },
  {
    path:"addmenu",
    component:Addmenu,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'RESTAURANT' }
  },
  {
    path:'getallmenu',
    component:Getallmenu,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'RESTAURANT' }
  },
  {
    path:'getallmenu/updatemenu/:id',
    component:Updatemenu,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'RESTAURANT' } 
  },
  {
    path:'instock',
    component:Instock,
    canActivate:[RoleGuard,authguardGuard],data: { expectedRole: 'RESTAURANT' }
  },
  {
    path:'outstock',
    component:Outstock,
     canActivate:[RoleGuard,authguardGuard],data: { expectedRole: 'RESTAURANT' }
  },
  {
    path:"userdashboard",
    component:Userdashboard,
    canActivate: [RoleGuard,authguardGuard], data: { expectedRole: 'USER' }
  },
  {
    path:'setprofile',
    component:Setprofile,
   canActivate:[RoleGuard,authguardGuard],data: { expectedRole: 'RESTAURANT' }
  },
  {
    path:'getmenuuser/:id',
    component:Getmenuuser,
   canActivate:[RoleGuard,authguardGuard],data: { expectedRole: 'USER' }
  },
  {
    path:'cart',
    component:Cart,
    canActivate:[RoleGuard,authguardGuard],data:{ expectedRole:"USER"}
  },
  {
    path:'checkout',
    component:Checkout,
    canActivate:[RoleGuard,authguardGuard],data:{expectedRole:'USER'}
  },
  {
    path:'summaryorder/:id',
    component:Summaryorder,
    canActivate:[RoleGuard,authguardGuard],data:{expectedRole :'USER'}
  },
  {
    path:'orderview',
    component:Orderview,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'USER'
    }
  },
  {
    path:'ordermanagement',
    component:Ordermanagement,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'pendingorders',
    component:Pendingorder,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'processingorder',
    component:Processingorder,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'outfordelivery',
    component:Outfordelivery,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'orderhistory',
    component:Orderhistory,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'navorder',
    component:Navorder,
     canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'RESTAURANT'
    }
  },
  {
    path:'usermanagement',
    component:Usermanagement,
    canActivate:[RoleGuard,authguardGuard],data:{expectedRole:'ADMIN'}
  },
    {
    path:'userUi',
    component:UserUi,
    canActivate:[RoleGuard,authguardGuard],data:{expectedRole:'ADMIN'}
  },{
    path:'adduser',
    component:Adduser,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'deleteuser',
    component:Deleteuser,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'restaurantUi',
    component:RestaurantUi,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'addrestaurant',
    component:Addrestaurant,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'deleterestaurant',
    component:Deleterestaurant,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'adminmenu',
    component:Adminmenu,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
    
  },
  {
    path:'viewrestaurant',
    component:Viewrestaurant,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  },
  {
    path:'adminviewmenu/:id',
    component:Adminviewmenu,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  }
  ,{
    path:'adminupdatemenu/:id',
    component:Adminupdatemenu,
    canActivate:[RoleGuard,authguardGuard],data:{
      expectedRole:'ADMIN'
    }
  }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
