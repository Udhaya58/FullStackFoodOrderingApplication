import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Restaurantservice } from '../restaurantservice';

@Component({
  selector: 'app-instock',
  standalone: false,
  templateUrl: './instock.html',
  styleUrl: './instock.css'
})
export class Instock implements OnInit{
  id:any;
  menu!:any;
constructor(private resservice: Restaurantservice){

}
ngOnInit(){
  this.getmenubyavailabilitytrue();

}

getmenubyavailabilitytrue(){
  this.resservice.getmenubyavailabilitytrue().subscribe(res=>{
    console.log(res);
    this.menu=res;
  })
}
updatemenutooutofstock(id:any){
  this.resservice.updateMenuAvailablestocktoout(id).subscribe({
    next:res=>{
      console.log(res);
      this.getmenubyavailabilitytrue();
    }
  })
}

}
