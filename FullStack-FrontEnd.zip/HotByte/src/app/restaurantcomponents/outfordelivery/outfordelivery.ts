import { Component, OnInit } from '@angular/core';
import { Restaurantservice } from '../../restaurantservice';

@Component({
  selector: 'app-outfordelivery',
  standalone: false,
  templateUrl: './outfordelivery.html',
  styleUrl: './outfordelivery.css'
})
export class Outfordelivery implements OnInit{
  delivery:any;
  constructor(private resservice:Restaurantservice){

  }
  ngOnInit(): void {
    this.viewoutfordelivery();
      
  }
  viewoutfordelivery(){
    return this.resservice.viewoutfordelivery().subscribe({
      next:res=>{
        console.log(res);
        this.delivery=res;
      }
    })
  }
  setdelvered(id:number){
    return this.resservice.setdelivered(id).subscribe({
      next:res=>{
        console.log(res);
        this.viewoutfordelivery();
      }
    })
  }

}
