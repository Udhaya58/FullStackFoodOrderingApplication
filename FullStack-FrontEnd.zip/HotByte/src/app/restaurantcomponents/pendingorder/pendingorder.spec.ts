import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pendingorder } from './pendingorder';

describe('Pendingorder', () => {
  let component: Pendingorder;
  let fixture: ComponentFixture<Pendingorder>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Pendingorder]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pendingorder);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
