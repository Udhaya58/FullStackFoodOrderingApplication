import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navorder',
  standalone: false,
  templateUrl: './navorder.html',
  styleUrl: './navorder.css'
})
export class Navorder {
   constructor(private router:Router) {
    
   }

   logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('USER');


  this.router.navigate(['/login']);
}

}
