import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ordermanagement',
  standalone: false,
  templateUrl: './ordermanagement.html',
  styleUrl: './ordermanagement.css'
})
export class Ordermanagement {
  constructor(private router:Router) {
    
  }

  logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('RESTAURANT');


  this.router.navigate(['/login']);
}

}
