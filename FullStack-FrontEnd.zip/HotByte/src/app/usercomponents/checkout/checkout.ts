import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  standalone: false,
  templateUrl: './checkout.html',
  styleUrl: './checkout.css'
})
export class Checkout implements OnInit{
  cart:any;
  order:any={
    shippingAddress: '',
    paymentMethod: ''
  };
  id!:any;

  constructor(private userservice:Userservice,private route:Router){

  }
  ngOnInit(){

  }

  placeOrder(){
    this.userservice.placeorder(this.order).subscribe({
      next:res=>{
        console.log(res);
        this.id=res;
        this.route.navigate(['/summaryorder', this.id.id]);

      
        

      }
    })
  }

  logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('user');


  this.route.navigate(['/login']);
}
}
