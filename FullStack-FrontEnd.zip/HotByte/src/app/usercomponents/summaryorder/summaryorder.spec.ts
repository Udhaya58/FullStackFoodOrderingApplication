import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Summaryorder } from './summaryorder';

describe('Summaryorder', () => {
  let component: Summaryorder;
  let fixture: ComponentFixture<Summaryorder>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Summaryorder]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Summaryorder);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
