import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-orderview',
  standalone: false,
  templateUrl: './orderview.html',
  styleUrl: './orderview.css'
})
export class Orderview implements OnInit{
  orderList:any;
constructor(private userservice:Userservice,private route:Router){

}
ngOnInit(): void {
    this.vieworder();
}
vieworder(){
  return this.userservice.vieworder().subscribe({
    next:res=>{ 
      console.log(res);
      this.orderList=res;

    }
  })
}
 logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('user');


  this.route.navigate(['/login']);
}
}
