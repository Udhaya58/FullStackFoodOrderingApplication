import { Component } from '@angular/core';

@Component({
  selector: 'app-user-ui',
  standalone: false,
  templateUrl: './user-ui.html',
  styleUrl: './user-ui.css'
})
export class UserUi {

}
