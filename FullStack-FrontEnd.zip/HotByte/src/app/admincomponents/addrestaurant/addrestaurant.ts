import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-addrestaurant',
  standalone: false,
  templateUrl: './addrestaurant.html',
  styleUrl: './addrestaurant.css'
})
export class Addrestaurant implements OnInit{
  restaurant!:FormGroup;
  constructor(private adminser:Adminservice,private fb:FormBuilder){

  }
  ngOnInit(): void {
    this.restaurant=this.fb.group({
      name:[null,[Validators.required]],
      location:[null,[Validators.required]],
      contact:[null,[Validators.required]],
      email:[null,[Validators.required]],
      password:[null,[Validators.required]]
    }

    )
    
      
  }
  addres(){
    return this.adminser.addrestaurant(this.restaurant.value).subscribe({
      next:res=>{
        console.log(res);
      }
    })
  }
  

}
