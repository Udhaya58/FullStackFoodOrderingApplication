import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Deleteuser } from './deleteuser';

describe('Deleteuser', () => {
  let component: Deleteuser;
  let fixture: ComponentFixture<Deleteuser>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Deleteuser]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Deleteuser);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
