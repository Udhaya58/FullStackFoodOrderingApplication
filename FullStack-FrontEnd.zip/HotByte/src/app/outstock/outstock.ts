import { Component, OnInit } from '@angular/core';
import { Restaurantservice } from '../restaurantservice';

@Component({
  selector: 'app-outstock',
  standalone: false,
  templateUrl: './outstock.html',
  styleUrl: './outstock.css'
})
export class Outstock implements OnInit{
  id!:any;
  menu:any;
  constructor(private resservice:Restaurantservice){

  }
  ngOnInit(){
    this.getmenbyavailablefalse();



  }

  getmenbyavailablefalse(){
    this.resservice.getbyavailablefalse().subscribe({next:res=>{
      console.log(res);
      this.menu=res;
    }})
  }
updatemenutoinstock(id:any){
  this.resservice.updateMenubyinstock(id).subscribe({
   next: res=>{
      console.log(res);
      this.getmenbyavailablefalse();
    }
  })
}



}
