import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Setprofile } from './setprofile';

describe('Setprofile', () => {
  let component: Setprofile;
  let fixture: ComponentFixture<Setprofile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Setprofile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Setprofile);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
