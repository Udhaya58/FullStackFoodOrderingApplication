import { Component, OnInit } from '@angular/core';
import { Restaurantservice } from '../restaurantservice';

@Component({
  selector: 'app-setprofile',
  standalone: false,
  templateUrl: './setprofile.html',
  styleUrl: './setprofile.css'
})
export class Setprofile implements OnInit{
      profile:any=[];

  constructor(private profileser:Restaurantservice){

  }
  ngOnInit(){
    this.setprofile();

  }

setprofile(){
  return this.profileser.setprofile().subscribe({
    next:res=>{
      console.log(res);
      this.profile=res;
    }
  })
}






}
