import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Getallmenu } from './getallmenu';

describe('Getallmenu', () => {
  let component: Getallmenu;
  let fixture: ComponentFixture<Getallmenu>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Getallmenu]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Getallmenu);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
