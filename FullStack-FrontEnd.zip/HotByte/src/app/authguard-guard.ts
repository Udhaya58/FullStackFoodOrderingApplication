import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authguardGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('jwtToken');

  if (!token) {
    return router.parseUrl('/login');
  }

  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const now = Math.floor(Date.now() / 1000);

    if (payload.exp && payload.exp > now) {
      return true; 
    } else {
      localStorage.removeItem('jwtToken'); 
      return router.parseUrl('/login');
    }
  } catch (e) {
    console.error('Invalid token format', e);
    localStorage.removeItem('jwtToken');
    return router.parseUrl('/login');
  }
};
